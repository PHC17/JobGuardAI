"""JobGuard AI entry point. Run with:  streamlit run app.py

app.py runs on every rerun, before the active page: it sets up state, applies
the theme and renders the sidebar brand. Navigation is explicit, so the four
pages in pages/ are the only screens.
"""
import streamlit as st

from src import ui
from src.app_state import init_state, save_state

st.set_page_config(
    page_title="JobGuard AI",
    page_icon=":material/shield:",
    layout="wide",
    initial_sidebar_state="expanded",
)

init_state()
ui.inject_theme()
ui.sidebar_brand()

navigation = st.navigation(
    [
        st.Page("pages/01_Screen_Job.py", title="Screen job", icon=":material/policy:", default=True),
        st.Page("pages/02_Batch_Screen.py", title="Batch screen", icon=":material/upload_file:"),
        st.Page("pages/03_Risk_Insights.py", title="Risk insights", icon=":material/insights:"),
        st.Page("pages/04_Settings.py", title="Settings", icon=":material/tune:"),
    ]
)
navigation.run()
save_state()  # mirror widget values after the page ran, so pv() can restore them later
