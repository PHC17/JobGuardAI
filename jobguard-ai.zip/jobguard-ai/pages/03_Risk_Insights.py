"""Risk insights: patterns in what you screened, the strongest signals, and the scam pattern library."""
from __future__ import annotations

from collections import Counter

import plotly.graph_objects as go
import streamlit as st

from src import ui
from src.app_state import get_bundle
from src.model import global_importance
from src.risk import LEVELS
from src.rules import SIGNAL_LIBRARY

ui.page_header(
    "Risk insights",
    "See which warning signs show up most in your screening, and which patterns matter most.",
)

history: list[dict] = st.session_state.get("history", [])
palette = ui.palette()

# -- Patterns in this session ---------------------------------------------------
left, right = st.columns(2, gap="large")

with left:
    with st.container(key="card_dist"):
        ui.section_title("Risk levels screened", "Postings screened in this session.")
        if not history:
            st.markdown("Nothing screened yet. Screen a posting or upload a batch to see patterns here.")
        else:
            counts = Counter(h["level"] for h in history)
            fig = go.Figure(go.Bar(
                x=list(LEVELS), y=[counts.get(l, 0) for l in LEVELS],
                marker_color=[palette[l] for l in LEVELS], text=[counts.get(l, 0) for l in LEVELS],
                textposition="outside", textfont=dict(color=palette["text"]),
                hovertemplate="%{x}: %{y} postings<extra></extra>",
            ))
            ui.style_figure(fig, height=300)
            fig.update_xaxes(gridcolor="rgba(0,0,0,0)")
            fig.update_yaxes(gridcolor=palette["border"], visible=True, title_text="Postings", title_font=dict(color=palette["muted"], size=12))
            st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

with right:
    with st.container(key="card_signals"):
        ui.section_title("Most common warning signs", "Signals found most often in your screened postings.")
        label_counts = Counter(lbl for h in history for lbl in h.get("labels", []))
        if not label_counts:
            st.markdown("No warning signs recorded yet.")
        else:
            top = label_counts.most_common(8)[::-1]
            fig = go.Figure(go.Bar(
                x=[c for _, c in top], y=[l for l, _ in top], orientation="h",
                marker_color=palette["accent"], hovertemplate="%{y}: %{x} postings<extra></extra>",
            ))
            ui.style_figure(fig, height=300)
            st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

# -- Strongest signals overall ------------------------------------------------------
with st.container(key="card_influence"):
    bundle = get_bundle()
    importance = global_importance(bundle)
    if importance:
        ui.section_title("Most influential signals", "The features that move the risk score the most, across all postings.")
        top = importance[::-1]
        fig = go.Figure(go.Bar(
            x=[v * 100 for _, v in top], y=[l for l, _ in top], orientation="h",
            marker_color=palette["accent"], hovertemplate="%{y}: %{x:.1f}% of influence<extra></extra>",
        ))
        ui.style_figure(fig, height=max(280, 30 * len(top) + 40))
        fig.update_xaxes(title_text="Share of influence (%)", title_font=dict(color=palette["muted"], size=12))
        st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
    else:
        ui.section_title("Signal strength", "How much each warning sign adds to the pattern-check score.")
        weights = list(SIGNAL_LIBRARY)[::-1]
        fig = go.Figure(go.Bar(
            x=[w * 100 for _, w in weights], y=[l for l, _ in weights], orientation="h",
            marker_color=palette["accent"], hovertemplate="%{y}: weight %{x:.0f}<extra></extra>",
        ))
        ui.style_figure(fig, height=360)
        fig.update_xaxes(title_text="Weight", title_font=dict(color=palette["muted"], size=12))
        st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})

# -- Pattern library -----------------------------------------------------------------------
PATTERNS = [
    ("Pay-to-work", "Fees for training, equipment, registration or background checks, or payment by gift card, crypto or wire.",
     "Real employers never charge applicants."),
    ("Identity harvesting", "Early requests for ID scans, bank details, date of birth or one-time passwords.",
     "Share these only after a verified, written offer."),
    ("Off-platform contact", "Pressure to continue on WhatsApp or Telegram, or contact from a free-mail address.",
     "Ask for a company email and verify the domain."),
    ("Too good to be true", "Guaranteed income, high pay with no experience or fast-money language.",
     "Compare the pay with similar roles."),
    ("Pressure and speed", "Instant hiring, chat-only interviews and limited slots.",
     "Take time to verify. Real hiring has real steps."),
]
with st.container(key="card_library"):
    ui.section_title("Common scam patterns", "What fraudulent postings tend to look like.")
    rows = "".join(
        f'<div class="jg-item"><span class="jg-dot" style="background:{palette["High"]}"></span>'
        f'<div><b>{ui.esc(name)}</b><small style="color:var(--jg-text)">{ui.esc(desc)}</small>'
        f'<small>{ui.esc(tip)}</small></div></div>'
        for name, desc, tip in PATTERNS
    )
    ui.html(rows)
