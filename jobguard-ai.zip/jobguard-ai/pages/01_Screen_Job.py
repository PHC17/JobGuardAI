"""Primary screening page: enter, upload or link a job posting and get a risk verdict."""
from __future__ import annotations

import plotly.graph_objects as go
import streamlit as st

from src import config, ui
from src.app_state import FORM_DEFAULTS, FORM_KEYS, get_pipeline, pv, record_history, screening_config
from src.features import JobPosting
from src.ingest import (
    ImportedPosting, IngestError, extract_text_from_file, fetch_job_page, posting_from_text,
)
from src.pipeline import ScreeningResult

NOT_SPECIFIED = ""
EMPLOYMENT_OPTIONS = [NOT_SPECIFIED, *config.EMPLOYMENT_TYPES]
EXPERIENCE_OPTIONS = [NOT_SPECIFIED, *config.EXPERIENCE_LEVELS]
EDUCATION_OPTIONS = [NOT_SPECIFIED, *config.EDUCATION_LEVELS]


def _fmt(option: str) -> str:
    return option or "Not specified"


# ---------------------------------------------------------------------------
# State helpers
# ---------------------------------------------------------------------------
def reset_form() -> None:
    """on_click callback: runs before the next script run, so widget keys may be set."""
    for key in FORM_KEYS:
        st.session_state[key] = FORM_DEFAULTS[key]
    st.session_state.pop("last_screening", None)


def apply_import(imp: ImportedPosting) -> None:
    """Prefill the form from an imported posting. Only non-empty fields overwrite."""
    mapping = {
        "f_title": imp.title, "f_company_profile": imp.company_profile,
        "f_description": imp.description, "f_requirements": imp.requirements,
        "f_salary_range": imp.salary_range, "f_industry": imp.industry,
    }
    for key, value in mapping.items():
        if value:
            st.session_state[key] = value[: config.MAX_FIELD_CHARS]
    if imp.employment_type in EMPLOYMENT_OPTIONS and imp.employment_type:
        st.session_state["f_employment_type"] = imp.employment_type
    if imp.telecommuting:
        st.session_state["f_telecommuting"] = True
    st.session_state.pop("last_screening", None)


def posting_from_form() -> JobPosting:
    s = st.session_state
    return JobPosting(
        title=s["f_title"], company_profile=s["f_company_profile"], description=s["f_description"],
        requirements=s["f_requirements"], benefits=s["f_benefits"], salary_range=s["f_salary_range"],
        employment_type=s["f_employment_type"], required_experience=s["f_required_experience"],
        required_education=s["f_required_education"], industry=s["f_industry"], function=s["f_function"],
        telecommuting=bool(s["f_telecommuting"]), has_company_logo=bool(s["f_has_company_logo"]),
        has_questions=bool(s["f_has_questions"]),
    )


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------
ui.page_header(
    "Screen a job posting",
    "Check a posting for fraud signals before you apply or publish. Enter the details, upload a file or paste a link.",
    with_agent=True,
)

left, right = st.columns([1.12, 1], gap="large")

with left:
    # -- Import (file / link) ------------------------------------------------
    with st.expander("Import from a file or link", expanded=False):
        tab_file, tab_url = st.tabs(["Upload file", "Job link"])

        with tab_file:
            uploaded = st.file_uploader(
                "Posting file", type=["txt", "md", "pdf", "docx"], key="import_file",
                help=f"Up to {config.MAX_DOC_MB} MB. PDF, Word or plain text.",
            )
            if st.button("Import file", key="btn_import_file", disabled=uploaded is None):
                try:
                    text = extract_text_from_file(uploaded.name, uploaded.getvalue())
                    apply_import(posting_from_text(text, source=uploaded.name))
                    st.toast("File imported. Review the fields below.", icon=":material/check_circle:")
                except IngestError as exc:
                    st.warning(str(exc))

        with tab_url:
            url = st.text_input("Job posting link", key="import_url", placeholder="https://company.com/careers/role")
            if st.button("Import link", key="btn_import_url", disabled=not url.strip()):
                with st.spinner("Reading the page"):
                    try:
                        imported = fetch_job_page(url)
                        apply_import(imported)
                        st.toast("Link imported. Review the fields below.", icon=":material/check_circle:")
                    except IngestError as exc:
                        st.warning(str(exc))
            st.caption("Only public pages are fetched. Links to private or internal addresses are blocked.")

    # -- Posting form ----------------------------------------------------------
    with st.container(key="card_form"):
        with st.form("screen_form", border=False):
            ui.section_title("Posting details")
            st.text_input("Job title", key="f_title", value=pv("f_title"), placeholder="e.g. Customer Support Associate")
            st.text_area("Company profile", key="f_company_profile", value=pv("f_company_profile"), height=96,
                         placeholder="Who is hiring? Paste the company description.")
            st.text_area("Job description", key="f_description", value=pv("f_description"), height=200,
                         placeholder="Paste the full description, including contact details.")
            st.text_area("Requirements", key="f_requirements", value=pv("f_requirements"), height=96)
            st.text_area("Benefits", key="f_benefits", value=pv("f_benefits"), height=80)

            ui.section_title("Role details", "Optional, but more detail gives a more accurate result.")
            c1, c2 = st.columns(2)
            c1.selectbox("Employment type", EMPLOYMENT_OPTIONS, key="f_employment_type", index=EMPLOYMENT_OPTIONS.index(pv("f_employment_type")), format_func=_fmt)
            c2.selectbox("Experience level", EXPERIENCE_OPTIONS, key="f_required_experience", index=EXPERIENCE_OPTIONS.index(pv("f_required_experience")), format_func=_fmt)
            c3, c4 = st.columns(2)
            c3.selectbox("Education", EDUCATION_OPTIONS, key="f_required_education", index=EDUCATION_OPTIONS.index(pv("f_required_education")), format_func=_fmt)
            c4.text_input("Salary range", key="f_salary_range", value=pv("f_salary_range"), placeholder="e.g. 40,000 - 55,000 per year")
            c5, c6 = st.columns(2)
            c5.text_input("Industry", key="f_industry", value=pv("f_industry"))
            c6.text_input("Job function", key="f_function", value=pv("f_function"))

            t1, t2, t3 = st.columns(3)
            t1.toggle("Remote", key="f_telecommuting", value=bool(pv("f_telecommuting")))
            t2.toggle("Company logo", key="f_has_company_logo", value=bool(pv("f_has_company_logo")))
            t3.toggle("Questions", key="f_has_questions", value=bool(pv("f_has_questions")))

            b1, b2 = st.columns([2, 1])
            submitted = b1.form_submit_button("Screen posting", type="primary", width="stretch")
            b2.form_submit_button("Clear", on_click=reset_form, width="stretch")

    # -- Run screening ---------------------------------------------------------
    if submitted:
        posting = posting_from_form()
        if len((posting.title + posting.description + posting.company_profile).strip()) < 30:
            st.toast("Add a title or description to screen.", icon=":material/warning:")
        else:
            cfg = screening_config()
            with st.spinner("Screening posting"):
                result = get_pipeline().screen(posting, cfg)
            st.session_state["last_screening"] = {"result": result, "bands": cfg.bands, "title": posting.title}
            record_history([{
                "title": posting.title[:90], "score": result.score, "level": result.level,
                "rules": [h.rule_id for h in result.rule_hits], "labels": [h.label for h in result.rule_hits],
            }])
            if result.level in ("Critical", "High"):
                st.toast(f"{result.level} risk. Do not proceed until verified.", icon=":material/error:")
            elif result.level == "Medium":
                st.toast("Medium risk. Verify the employer.", icon=":material/warning:")
            else:
                st.toast("Screening complete. Low risk.", icon=":material/check_circle:")


# ---------------------------------------------------------------------------
# Results
# ---------------------------------------------------------------------------
def render_empty() -> None:
    ui.html(f"""
    <div class="jg-empty"><img src="{ui.agent_uri()}" alt="">
    <p class="jg-title" style="margin-top:16px">Ready to screen</p>
    <p class="jg-sub">Add a posting on the left and select Screen posting. Your risk score and next steps appear here.</p></div>
    """)


def render_findings(result: ScreeningResult) -> None:
    if not result.rule_hits:
        st.markdown("No warning signs were found in the text or structure of this posting.")
        return
    rows = ""
    for hit in result.rule_hits[:6]:
        color = ui.level_color("Critical" if hit.weight >= 0.4 else "High" if hit.weight >= 0.2 else "Medium")
        chips = "".join(f'<span class="jg-chip">{ui.esc(e)}</span>' for e in hit.evidence)
        rows += (
            f'<div class="jg-item"><span class="jg-dot" style="background:{color}"></span>'
            f'<div><b>{ui.esc(hit.label)}</b><small>{ui.esc(hit.detail)}</small>{chips}</div></div>'
        )
    ui.html(rows)


def render_recommendations(result: ScreeningResult) -> None:
    rows = ""
    for rec in result.recommendations:
        because = f"<small>{ui.esc(rec.because)}</small>" if rec.because else ""
        rows += (
            f'<div class="jg-item"><span class="jg-dot" style="background:{ui.palette()["accent"]}"></span>'
            f'<div><b>{ui.esc(rec.title)}</b><small style="color:var(--jg-text)">{ui.esc(rec.detail)}</small>{because}</div></div>'
        )
    ui.html(rows)


def render_technical(result: ScreeningResult) -> None:
    p = ui.palette()
    ui.html(
        f'<div class="jg-kv"><span>Blended risk score</span><b>{result.score * 100:.0f} / 100</b></div>'
        f'<div class="jg-kv"><span>Pattern-check score</span><b>{result.heuristic_score * 100:.0f} / 100</b></div>'
        f'<div class="jg-kv"><span>Language-model score</span><b>'
        f'{"n/a" if result.ml_probability is None else f"{result.ml_probability * 100:.0f} / 100"}</b></div>'
    )
    if result.rule_hits:
        st.markdown("**Rule hits**")
        st.dataframe(
            [{"Signal": h.label, "Category": h.category, "Weight": h.weight,
              "Evidence": "; ".join(h.evidence) or "-"} for h in result.rule_hits],
            hide_index=True, width="stretch",
        )
    if result.contributions:
        st.markdown("**Top model drivers**")
        items = sorted(result.contributions, key=lambda c: c.value)
        fig = go.Figure(go.Bar(
            x=[c.value for c in items], y=[c.label for c in items], orientation="h",
            marker_color=[p["High"] if c.value > 0 else p["Low"] for c in items],
            hovertemplate="%{y}<br>%{x:+.3f}<extra></extra>",
        ))
        ui.style_figure(fig, height=max(240, 34 * len(items) + 40))
        fig.update_xaxes(title_text="Pushes risk down  |  up", title_font=dict(color=p["muted"], size=12))
        st.plotly_chart(fig, width="stretch", config={"displayModeBar": False})
    elif result.engine == "rules":
        st.caption("Model explanations are unavailable: running on the pattern checks only.")


with right:
    with st.container(key="results_panel"):
        last = st.session_state.get("last_screening")
        if not last:
            with st.container(key="card_empty"):
                render_empty()
        else:
            res: ScreeningResult = last["result"]
            with st.container(key="card_verdict"):
                ui.gauge(res.score, res.level, last["bands"])
                st.markdown(f'<p class="jg-verdict">{ui.esc(res.headline)}</p>', unsafe_allow_html=True)
                n = len(res.rule_hits)
                st.caption("No warning signs found" if n == 0 else f"{n} warning sign{'s' if n != 1 else ''} found")
            with st.container(key="card_actions"):
                ui.section_title("What to do next")
                render_recommendations(res)
            with st.container(key="card_findings"):
                ui.section_title("Warning signs")
                render_findings(res)
            with st.expander("Technical details"):
                render_technical(res)
