"""Bulk CSV screening with summary metrics and a downloadable, colour-coded results table."""
from __future__ import annotations

import io

import pandas as pd
import streamlit as st

from src import config, ui
from src.app_state import get_pipeline, record_history, screening_config
from src.pipeline import postings_from_frame, results_to_frame, sanitize_for_csv
from src.risk import LEVELS

TEXT_COLUMNS = ("title", "company_profile", "description", "requirements", "benefits")
TEMPLATE_COLUMNS = (
    "title", "company_profile", "description", "requirements", "benefits", "salary_range",
    "employment_type", "required_experience", "required_education", "industry", "function",
    "telecommuting", "has_company_logo", "has_questions",
)

ui.page_header(
    "Batch screening",
    "Upload a CSV of postings to rank them by risk. Review the highest-risk rows first.",
)

# -- Upload ------------------------------------------------------------------
with st.container(key="card_upload"):
    ui.section_title("Upload postings", f"CSV, up to {config.MAX_CSV_MB} MB and {config.MAX_BATCH_ROWS:,} rows. Missing columns are treated as empty.")
    uploaded = st.file_uploader("CSV file", type=["csv"], key="batch_file", label_visibility="collapsed")
    c1, c2 = st.columns([1, 1])
    run = c1.button("Screen file", type="primary", disabled=uploaded is None, width="stretch")
    c2.download_button(
        "Download CSV template",
        data=(",".join(TEMPLATE_COLUMNS) + "\n").encode("utf-8"),
        file_name="jobguard_template.csv", mime="text/csv", width="stretch",
    )


def read_csv(file) -> pd.DataFrame:
    if file.size > config.MAX_CSV_MB * 1024 * 1024:
        raise ValueError(f"The file is larger than {config.MAX_CSV_MB} MB.")
    try:
        df = pd.read_csv(
            io.BytesIO(file.getvalue()), dtype=str, nrows=config.MAX_BATCH_ROWS + 1,
            encoding="utf-8-sig", encoding_errors="replace", on_bad_lines="skip",
        )
    except (pd.errors.ParserError, pd.errors.EmptyDataError) as exc:
        raise ValueError("The file could not be read as a CSV.") from exc
    df.columns = [str(c).strip().lower() for c in df.columns]
    if not any(c in df.columns for c in TEXT_COLUMNS):
        raise ValueError("No posting columns found. Include at least one of: " + ", ".join(TEXT_COLUMNS) + ".")
    if df.empty:
        raise ValueError("The file has no rows.")
    return df


# -- Run ---------------------------------------------------------------------
if run and uploaded is not None:
    try:
        frame = read_csv(uploaded)
        truncated = len(frame) > config.MAX_BATCH_ROWS
        frame = frame.head(config.MAX_BATCH_ROWS).reset_index(drop=True)
        bar = st.progress(0.0, text="Screening postings")
        results = get_pipeline().screen_many(
            postings_from_frame(frame), screening_config(), progress=lambda f: bar.progress(f, text="Screening postings"),
        )
        bar.empty()
        table = results_to_frame(frame, results)
        st.session_state["batch"] = {"table": table, "name": uploaded.name}
        record_history([
            {"title": r["title"], "score": r["risk_score"] / 100, "level": r["risk_level"],
             "rules": [], "labels": [s for s in r["top_signals"].split("; ") if s]}
            for r in table.to_dict(orient="records")
        ])
        st.toast(f"Screened {len(table):,} postings.", icon=":material/check_circle:")
        if truncated:
            st.toast(f"Only the first {config.MAX_BATCH_ROWS:,} rows were screened.", icon=":material/warning:")
    except ValueError as exc:
        st.toast(str(exc), icon=":material/error:")
        st.error(str(exc))

# -- Results -----------------------------------------------------------------
batch = st.session_state.get("batch")
if not batch:
    with st.container(key="card_batch_empty"):
        st.markdown("**No results yet.** Upload a CSV and select Screen file to see a ranked list.")
else:
    table: pd.DataFrame = batch["table"]
    counts = table["risk_level"].value_counts().to_dict()
    flagged = counts.get("Critical", 0) + counts.get("High", 0)

    cols = st.columns(5)
    tiles = [
        ("Postings screened", f"{len(table):,}", None),
        ("Critical", f"{counts.get('Critical', 0):,}", ui.level_color("Critical")),
        ("High", f"{counts.get('High', 0):,}", ui.level_color("High")),
        ("Medium", f"{counts.get('Medium', 0):,}", ui.level_color("Medium")),
        ("Low", f"{counts.get('Low', 0):,}", ui.level_color("Low")),
    ]
    for col, (label, value, color) in zip(cols, tiles):
        col.markdown(ui.metric_tile(label, value, color), unsafe_allow_html=True)
    st.caption(f"{flagged:,} of {len(table):,} postings ({flagged / len(table):.0%}) need review before use. Source: {batch['name']}")

    with st.container(key="card_results"):
        f1, f2 = st.columns([2, 1])
        shown = f1.multiselect("Risk levels", LEVELS, default=list(LEVELS), key="batch_filter")
        order = f2.selectbox("Sort by", ["Highest risk first", "Original order"], key="batch_sort")
        view = table[table["risk_level"].isin(shown)]
        if order == "Highest risk first":
            view = view.sort_values(["risk_score", "row"], ascending=[False, True])

        palette = ui.palette()

        def paint(level: str) -> str:
            c = palette.get(level, palette["muted"])
            return f"background-color:{c}26;color:{c};font-weight:650;text-align:center"

        styled = view.style.map(paint, subset=["risk_level"])
        st.dataframe(
            styled, hide_index=True, width="stretch", height=440,
            column_config={
                "row": st.column_config.NumberColumn("Row", width="small"),
                "title": st.column_config.TextColumn("Title", width="medium"),
                "company": st.column_config.TextColumn("Company", width="medium"),
                "risk_score": st.column_config.ProgressColumn("Risk score", min_value=0, max_value=100, format="%d"),
                "risk_level": st.column_config.TextColumn("Level", width="small"),
                "top_signals": st.column_config.TextColumn("Top signals", width="large"),
                "recommended_action": st.column_config.TextColumn("Recommended action", width="large"),
            },
        )
        st.download_button(
            "Download results (CSV)",
            data=sanitize_for_csv(view).to_csv(index=False).encode("utf-8-sig"),
            file_name="jobguard_results.csv", mime="text/csv", type="primary",
        )
