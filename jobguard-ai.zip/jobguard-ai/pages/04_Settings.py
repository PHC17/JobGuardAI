"""Settings: sensitivity threshold with live preview, appearance, audience and model status."""
from __future__ import annotations

import streamlit as st

from src import ui
from src.app_state import get_bundle, get_settings, pv
from src.risk import bands_from_threshold, level_for

ui.page_header("Settings", "Tune how strictly postings are flagged and how results are presented.")

settings = get_settings()
bundle = get_bundle()

left, right = st.columns([1.2, 1], gap="large")

with left:
    # -- Sensitivity ---------------------------------------------------------------
    with st.container(key="card_sensitivity"):
        ui.section_title("Detection sensitivity", "Postings scoring at or above this value are flagged as High risk.")
        st.slider("Flag threshold", min_value=0.20, max_value=0.90, value=float(pv("s_threshold")), step=0.05, key="s_threshold",
                  help="Lower values flag more postings. Raise it to reduce false alarms.")
        bands = bands_from_threshold(float(pv("s_threshold")))

        ui.html(ui.band_bar(bands))
        ui.html(
            f'<div class="jg-kv"><span>Low</span><b>below {bands.medium * 100:.0f}</b></div>'
            f'<div class="jg-kv"><span>Medium</span><b>{bands.medium * 100:.0f} to {bands.high * 100:.0f}</b></div>'
            f'<div class="jg-kv"><span>High</span><b>{bands.high * 100:.0f} to {bands.critical * 100:.0f}</b></div>'
            f'<div class="jg-kv"><span>Critical</span><b>{bands.critical * 100:.0f} and above</b></div>'
        )

        st.markdown("**Preview**")
        sample = st.slider("Try a sample score", 0, 100, 60, key="preview_score")
        level = level_for(sample / 100, bands)
        ui.html(f'<p class="jg-sub">A posting scoring {sample} would be rated &nbsp;{ui.badge(level)}</p>')

    # -- Advanced ------------------------------------------------------------------------
    with st.expander("Advanced"):
        st.slider(
            "Weight of the language model in the blended score", 0.30, 0.90, value=float(pv("s_ml_weight")), step=0.05, key="s_ml_weight",
            disabled=not bundle.loaded,
            help="The remainder comes from the pattern checks. Only applies when a trained model is available.",
        )
        if not bundle.loaded:
            st.caption("No trained model is loaded, so scores come from the pattern checks.")

with right:
    # -- Appearance and audience -------------------------------------------------------------------
    with st.container(key="card_appearance"):
        ui.section_title("Appearance")
        # A cleared segmented control reads as None; theme_mode() and get_settings() fall back to defaults.
        st.segmented_control("Theme", ["Dark", "Light"], key="s_theme", default=pv("s_theme"), selection_mode="single")
        ui.section_title("Recommendations for")
        st.segmented_control("Audience", ["Job seeker", "Recruiter"], key="s_audience", default=pv("s_audience"), selection_mode="single",
                             label_visibility="collapsed")
        st.caption("Changes the wording of next steps. Job seekers see how to stay safe; recruiters see how to handle the posting.")

    # -- Model ----------------------------------------------------------------------------------------
    with st.container(key="card_model"):
        ui.section_title("Model")
        engine = "Hybrid (language model + pattern checks)" if bundle.loaded else "Pattern checks only"
        rows = [("Engine", engine), ("Model version", bundle.version)]
        if bundle.released:
            rows.append(("Released", bundle.released))
        rows.append(("Explanations", "Available" if bundle.explainer_ok else "Unavailable"))
        ui.html("".join(f'<div class="jg-kv"><span>{ui.esc(k)}</span><b>{ui.esc(v)}</b></div>' for k, v in rows))
        for note in bundle.notes:
            st.caption(note)
