"""Streamlit smoke tests: every page renders without exceptions and the main flow works."""
from __future__ import annotations

from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent
SCAM_TEXT = (
    "URGENT HIRING!!! Earn $500 per day, no experience required. Pay a registration fee via gift card and send "
    "your bank account number to hr.jobs@gmail.com or contact us on WhatsApp. No interview needed."
)


def new_app() -> AppTest:
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60)
    at.run()
    return at


def test_home_page_renders_empty_state():
    at = new_app()
    assert not at.exception
    assert any("Ready to screen" in m.value for m in at.markdown)


def test_screening_flow_produces_critical_result_and_history():
    at = new_app()
    at.text_input(key="f_title").set_value("Data Entry Executive")
    at.text_area(key="f_description").set_value(SCAM_TEXT)
    # The primary form button is the first form submit button.
    submit = next(b for b in at.button if b.label == "Screen posting")
    submit.click().run()
    assert not at.exception
    last = at.session_state["last_screening"]
    assert last["result"].level == "Critical"
    assert len(at.session_state["history"]) == 1
    assert any("Critical risk" in m.value for m in at.markdown)  # badge rendered
    # untrusted text never reaches the page unescaped
    assert not any("<script" in m.value.lower() for m in at.markdown)


def test_short_input_is_rejected_with_toast():
    at = new_app()
    next(b for b in at.button if b.label == "Screen posting").click().run()
    assert not at.exception
    assert "last_screening" not in at.session_state
    assert any("Add a title or description" in t.value for t in at.toast)


def test_clear_resets_form_and_result():
    at = new_app()
    at.text_area(key="f_description").set_value(SCAM_TEXT)
    next(b for b in at.button if b.label == "Screen posting").click().run()
    assert "last_screening" in at.session_state
    next(b for b in at.button if b.label == "Clear").click().run()
    assert at.session_state["f_description"] == "" and "last_screening" not in at.session_state


@pytest.mark.parametrize("page", ["pages/02_Batch_Screen.py", "pages/03_Risk_Insights.py", "pages/04_Settings.py"])
def test_other_pages_render(page):
    at = new_app()
    at.switch_page(page).run()
    assert not at.exception


def test_settings_render_after_navigation_round_trip():
    """Form/setting persistence across pages is verified end to end in a real browser
    (AppTest does not reproduce Streamlit's end-of-run widget cleanup), so here we only
    check that a round trip renders cleanly and the slider value is applied."""
    at = new_app()
    at.switch_page("pages/04_Settings.py").run()
    at.slider(key="s_threshold").set_value(0.7).run()
    at.switch_page("pages/01_Screen_Job.py").run()
    assert not at.exception
    at.switch_page("pages/04_Settings.py").run()
    assert not at.exception
