"""Engine tests. Run from the project root:  pytest -q"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src import ingest  # noqa: E402
from src.features import NUMERIC_FEATURES, JobPosting, extract_features, make_tfidf_vectorizer  # noqa: E402
from src.model import ModelBundle, load_bundle  # noqa: E402
from src.pipeline import (  # noqa: E402
    ScreeningConfig, ScreeningPipeline, fuse_scores, postings_from_frame, results_to_frame, sanitize_for_csv,
)
from src.risk import bands_from_threshold, level_for  # noqa: E402

LEGIT = JobPosting(
    title="Senior Backend Engineer",
    company_profile="Northwind Systems builds logistics software for mid-sized retailers across Europe and has 400 employees.",
    description=(
        "You will design and maintain REST services in Python and PostgreSQL, review code, mentor two junior engineers "
        "and take part in the on-call rotation. The team works in two-week sprints and releases weekly. "
        "You will collaborate with product managers and designers to ship features that reduce delivery delays for our customers."
    ),
    requirements="5+ years of backend experience. Strong SQL. Experience with cloud infrastructure.",
    benefits="Health insurance, learning budget, 25 days of leave.",
    salary_range="70000-90000", employment_type="Full-time", has_company_logo=True, has_questions=True,
)

SCAM = JobPosting(
    title="URGENT HIRING!!! Data Entry - Work From Home",
    description=(
        "Earn $500 per day with no experience required! Limited slots, apply immediately. "
        "Pay a one-time registration fee of $50 via gift card. Send your passport copy and bank account number "
        "to jobs.hr.office@gmail.com or contact us on WhatsApp. No interview, you are hired instantly!!!"
    ),
)


# -- features ------------------------------------------------------------------------------------------
def test_feature_vector_has_contract_length_and_no_nan():
    f = extract_features(SCAM)
    assert set(f.numeric) == set(NUMERIC_FEATURES)
    assert f.vector().shape == (len(NUMERIC_FEATURES),)
    assert not np.isnan(f.vector()).any()


def test_empty_posting_does_not_crash():
    f = extract_features(JobPosting())
    assert f.numeric["word_count"] == 0 and f.numeric["missing_description"] == 1.0


def test_email_and_flag_extraction():
    f = extract_features(SCAM)
    assert f.personal_emails == ["jobs.hr.office@gmail.com"]
    assert {"advance_fee", "identity_harvest", "off_platform", "urgency", "interview_bypass"} <= set(f.flag_hits)
    assert f.pay_claims


def test_from_mapping_handles_nan_and_strings():
    p = JobPosting.from_mapping({"title": np.nan, "telecommuting": "1", "has_company_logo": "no", "description": "x"})
    assert p.title == "" and p.telecommuting is True and p.has_company_logo is False


def test_html_is_stripped():
    p = JobPosting(description="<p>Hello <b>world</b> &amp; team</p>")
    assert "<" not in extract_features(p).text


# -- rules / fusion / levels -------------------------------------------------------------------------------
def test_scam_scores_critical_and_legit_scores_low_without_model():
    pipe = ScreeningPipeline(ModelBundle())
    scam, legit = pipe.screen(SCAM), pipe.screen(LEGIT)
    assert scam.level == "Critical" and scam.score > 0.8 and scam.engine == "rules"
    assert legit.level == "Low" and legit.score < 0.3 and not legit.rule_hits
    assert scam.rule_hits[0].weight >= scam.rule_hits[-1].weight


def test_recommendations_reference_actual_evidence_and_audience():
    pipe = ScreeningPipeline(ModelBundle())
    seeker = pipe.screen(SCAM, ScreeningConfig(audience="job_seeker"))
    recruiter = pipe.screen(SCAM, ScreeningConfig(audience="recruiter"))
    assert any("registration fee" in r.because or "gift card" in r.because for r in seeker.recommendations)
    assert seeker.headline != recruiter.headline
    assert pipe.screen(LEGIT).level == "Low" and len(pipe.screen(LEGIT).recommendations) <= 3


def test_fusion_properties():
    assert fuse_scores(None, 0.4) == 0.4
    assert fuse_scores(0.2, 0.2) == pytest.approx(0.2)
    assert fuse_scores(0.05, 0.95) >= 0.85 * 0.95  # a strong rule hit is not diluted by a clean-looking text
    assert 0 <= fuse_scores(1.0, 1.0) <= 1


def test_bands_are_monotonic_for_every_threshold():
    for t in np.arange(0.2, 0.91, 0.05):
        b = bands_from_threshold(float(t))
        assert 0 < b.medium < b.high < b.critical <= 0.95
        assert level_for(0.0, b) == "Low" and level_for(1.0, b) == "Critical"


# -- batch / CSV ---------------------------------------------------------------------------------------------
def test_batch_matches_single_and_csv_is_sanitised():
    df = pd.DataFrame([
        {"title": "=HYPERLINK(\"http://evil\")", "description": SCAM.description},
        {"title": LEGIT.title, "description": LEGIT.description, "has_company_logo": "1"},
    ])
    pipe = ScreeningPipeline(ModelBundle())
    results = pipe.screen_many(postings_from_frame(df))
    assert results[0].level in ("High", "Critical") and results[1].score < results[0].score
    table = results_to_frame(df, results)
    assert sanitize_for_csv(table)["title"].iloc[0].startswith("'=")


def test_batch_row_limit():
    from src import config
    with pytest.raises(ValueError):
        postings_from_frame(pd.DataFrame({"title": ["x"] * (config.MAX_BATCH_ROWS + 1)}))


# -- trained-model path (synthetic artifacts, verifies the feature contract end to end) -------------------------
@pytest.fixture(scope="module")
def synthetic_models(tmp_path_factory):
    import joblib
    import shap
    from scipy import sparse
    from xgboost import XGBClassifier

    from src.features import numeric_matrix

    rng = np.random.default_rng(0)
    postings, labels = [], []
    for i in range(120):
        fraud = i % 2 == 0
        postings.append(JobPosting(
            title="Data Entry" if fraud else "Engineer",
            description=("registration fee whatsapp earn money fast " if fraud else "python sql team sprint review ")
            * int(rng.integers(3, 8)),
            has_company_logo=not fraud,
        ))
        labels.append(int(fraud))
    feats = [extract_features(p) for p in postings]
    vec = make_tfidf_vectorizer()
    vec.set_params(min_df=1)
    tfidf = vec.fit_transform([f.text for f in feats])
    X = sparse.hstack([tfidf, sparse.csr_matrix(numeric_matrix(feats))], format="csr", dtype=np.float32)
    clf = XGBClassifier(n_estimators=25, max_depth=3, random_state=0).fit(X, labels)
    d = tmp_path_factory.mktemp("models")
    joblib.dump(clf, d / "model.joblib")
    joblib.dump(vec, d / "vectorizer.joblib")
    joblib.dump(shap.TreeExplainer(clf), d / "explainer.joblib")
    (d / "meta.json").write_text(json.dumps({"version": "test-1", "released": "2026-10-30"}))
    return d


def test_trained_model_hybrid_scoring_and_explanations(synthetic_models):
    bundle = load_bundle(synthetic_models)
    assert bundle.loaded and bundle.explainer_ok and bundle.version == "test-1"
    pipe = ScreeningPipeline(bundle)
    scam, legit = pipe.screen(SCAM), pipe.screen(LEGIT)
    assert scam.engine == "hybrid" and scam.ml_probability is not None
    assert scam.score > legit.score
    assert scam.contributions and all(np.isfinite(c.value) for c in scam.contributions)
    batch = pipe.screen_many([SCAM, LEGIT])
    assert batch[0].ml_probability == pytest.approx(scam.ml_probability, abs=1e-5)


def test_missing_or_mismatched_models_fall_back(tmp_path, synthetic_models):
    assert not load_bundle(tmp_path).loaded
    import shutil
    d = tmp_path / "broken"
    shutil.copytree(synthetic_models, d)
    (d / "model.joblib").write_bytes(b"not a pickle")  # corrupt artifact must not crash the app
    assert not load_bundle(d).loaded


# -- ingestion security ----------------------------------------------------------------------------------------------
@pytest.mark.parametrize("url", [
    "ftp://example.com/x", "http://127.0.0.1/admin", "http://localhost/", "http://169.254.169.254/latest/meta-data/",
    "http://10.0.0.5/", "http://[::1]/", "https://user:pw@example.com/", "http://example.com:8080/", "javascript:alert(1)",
])
def test_ssrf_urls_are_rejected(url):
    with pytest.raises(ingest.IngestError):
        ingest.validate_public_url(url)


def test_json_ld_job_page_is_parsed():
    page = """<html><head><script type="application/ld+json">
    {"@context":"https://schema.org","@type":"JobPosting","title":"Analyst","description":"<p>Analyse data.</p><ul><li>SQL</li></ul>",
     "hiringOrganization":{"@type":"Organization","name":"Acme"},"employmentType":"FULL_TIME","jobLocationType":"TELECOMMUTE"}
    </script></head><body></body></html>"""
    imp = ingest.parse_job_html(page)
    assert imp.title == "Analyst" and imp.company_profile == "Acme"
    assert imp.employment_type == "Full-time" and imp.telecommuting and "SQL" in imp.description


def test_plain_page_fallback_strips_scripts():
    page = "<html><title>Role</title><body><script>steal()</script><main><p>" + "We are hiring a designer. " * 5 + "</p></main></body></html>"
    imp = ingest.parse_job_html(page)
    assert "steal" not in imp.description and "designer" in imp.description


def test_file_upload_guards():
    with pytest.raises(ingest.IngestError):
        ingest.extract_text_from_file("evil.exe", b"MZ")
    with pytest.raises(ingest.IngestError):
        ingest.extract_text_from_file("big.txt", b"a" * (6 * 1024 * 1024))
    assert "hiring" in ingest.extract_text_from_file("ok.txt", b"We are hiring a data analyst for our team.")
