"""Risk levels and the threshold -> band mapping shared by engine and UI."""
from __future__ import annotations

from dataclasses import dataclass

LEVELS = ("Low", "Medium", "High", "Critical")


@dataclass(frozen=True)
class RiskBands:
    """Lower bounds (0-1) at which each level starts."""

    medium: float
    high: float
    critical: float


def bands_from_threshold(threshold: float) -> RiskBands:
    """Derive all bands from the single 'flag as High' threshold.

    threshold=0.55 -> Medium from 0.30, High from 0.55, Critical from ~0.78.
    """
    t = min(max(float(threshold), 0.20), 0.90)
    return RiskBands(
        medium=round(t * 0.55, 4),
        high=round(t, 4),
        critical=round(min(0.95, t + (1.0 - t) * 0.5), 4),
    )


def level_for(score: float, bands: RiskBands) -> str:
    if score >= bands.critical:
        return "Critical"
    if score >= bands.high:
        return "High"
    if score >= bands.medium:
        return "Medium"
    return "Low"
