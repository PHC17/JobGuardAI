"""Feature engineering for job postings.

This module is the single source of truth for the feature contract. The same
code path must be used when training (to build the numeric block next to the
TF-IDF block) and when serving, otherwise predictions silently drift.

Feature matrix layout fed to the model:
    [ TF-IDF (unigrams + bigrams) | NUMERIC_FEATURES (fixed order) ]
"""
from __future__ import annotations

import html
import re
import string
import zlib
from dataclasses import dataclass, field
from typing import Any, Mapping
from urllib.parse import urlparse

import numpy as np
import textstat
from sklearn.feature_extraction.text import TfidfVectorizer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

from . import config

# ---------------------------------------------------------------------------
# Input model
# ---------------------------------------------------------------------------


def _to_str(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and np.isnan(value):
        return ""
    return str(value).strip()


def _to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)) and not (isinstance(value, float) and np.isnan(value)):
        return bool(value)
    return _to_str(value).lower() in {"1", "true", "yes", "y", "t"}


@dataclass
class JobPosting:
    """A single posting. Every field is optional; missing values are signals."""

    title: str = ""
    company_profile: str = ""
    description: str = ""
    requirements: str = ""
    benefits: str = ""
    salary_range: str = ""
    employment_type: str = ""
    required_experience: str = ""
    required_education: str = ""
    industry: str = ""
    function: str = ""
    location: str = ""
    telecommuting: bool = False
    has_company_logo: bool = False
    has_questions: bool = False

    @classmethod
    def from_mapping(cls, row: Mapping[str, Any]) -> "JobPosting":
        """Build from a dict / DataFrame row, tolerating NaN, None and missing keys."""
        text_fields = (
            "title", "company_profile", "description", "requirements", "benefits",
            "salary_range", "employment_type", "required_experience",
            "required_education", "industry", "function", "location",
        )
        bool_fields = ("telecommuting", "has_company_logo", "has_questions")
        kwargs: dict[str, Any] = {f: _to_str(row.get(f)) for f in text_fields}
        kwargs.update({f: _to_bool(row.get(f)) for f in bool_fields})
        return cls(**kwargs)


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------
_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE = re.compile(r"\s+")
_WORD_RE = re.compile(r"[A-Za-z0-9']+")
_SENT_SPLIT_RE = re.compile(r"[.!?]+")
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]{1,64}@[A-Za-z0-9.\-]{1,255}\.[A-Za-z]{2,24}")
_URL_RE = re.compile(r"(?:https?://|www\.)[^\s<>\"']{1,2048}", re.IGNORECASE)
_PAY_CLAIM_RE = re.compile(config.PAY_CLAIM_PATTERN, re.IGNORECASE)
_PUNCT = frozenset(string.punctuation)

_FLAG_PATTERNS: dict[str, re.Pattern[str]] = {
    group: re.compile(
        r"\b(?:" + "|".join(re.escape(p) for p in sorted(phrases, key=len, reverse=True)) + r")\b",
        re.IGNORECASE,
    )
    for group, phrases in config.RED_FLAG_GROUPS.items()
}

_vader = SentimentIntensityAnalyzer()


_VOWEL_GROUPS = re.compile(r"[aeiouy]+")


def _syllables(word: str) -> int:
    """Dependency-free syllable estimate (vowel groups, silent trailing 'e')."""
    w = word.lower().strip("'")
    n = len(_VOWEL_GROUPS.findall(w))
    if w.endswith("e") and not w.endswith(("le", "ee")) and n > 1:
        n -= 1
    return max(n, 1)


def _readability(text: str, words: list[str], n_sentences: int) -> tuple[float, float]:
    """(Flesch reading ease, Flesch-Kincaid grade).

    textstat is preferred, but it needs an nltk dictionary that may be missing
    or undownloadable (offline / locked-down hosts). In that case, or if it
    returns 0, use the same formulas with a heuristic syllable counter so the
    feature never silently collapses to a constant. Train and serve on the same
    environment so both paths see the same values.
    """
    try:
        fre = float(textstat.flesch_reading_ease(text))
        fkg = float(textstat.flesch_kincaid_grade(text))
        if fre != 0.0 or fkg != 0.0:
            return float(np.clip(fre, -50, 120)), float(np.clip(fkg, 0, 30))
    except Exception:  # noqa: BLE001 - textstat internals vary by version
        pass
    n_words = max(len(words), 1)
    sents = max(n_sentences, 1)
    syl = sum(_syllables(w) for w in words)
    wps, spw = n_words / sents, syl / n_words
    fre = 206.835 - 1.015 * wps - 84.6 * spw
    fkg = 0.39 * wps + 11.8 * spw - 15.59
    return float(np.clip(fre, -50, 120)), float(np.clip(fkg, 0, 30))


def clean_field(text: str) -> str:
    """Strip HTML, decode entities, collapse whitespace and cap the length."""
    text = text[: config.MAX_FIELD_CHARS]
    text = html.unescape(_TAG_RE.sub(" ", text))
    return _WS_RE.sub(" ", text).strip()


def combine_text(p: JobPosting) -> str:
    """title + company_profile + description + requirements + benefits."""
    parts = (p.title, p.company_profile, p.description, p.requirements, p.benefits)
    return " ".join(c for c in (clean_field(x) for x in parts) if c)


def _stable_bucket(value: str) -> int:
    """Process-independent hash bucket (Python's hash() is salted per process)."""
    v = value.strip().lower()
    if not v:
        return 0
    return zlib.crc32(v.encode("utf-8")) % config.HASH_BUCKETS + 1


def _ordinal(value: str, vocab: tuple[str, ...]) -> int:
    v = value.strip().lower()
    for i, item in enumerate(vocab, start=1):
        if item.lower() == v:
            return i
    return 0


def _email_domain(email: str) -> str:
    return email.rsplit("@", 1)[-1].lower()


# ---------------------------------------------------------------------------
# Feature contract
# ---------------------------------------------------------------------------
NUMERIC_FEATURES: tuple[str, ...] = (
    # text shape
    "word_count", "char_count", "avg_sentence_len", "uppercase_ratio",
    "exclamation_count", "punctuation_density",
    # language signals
    "red_flag_count", "flesch_reading_ease", "fk_grade", "sentiment_compound",
    # contact / links
    "email_count", "personal_email_count", "has_personal_email", "url_count",
    # binary flags
    "telecommuting", "has_company_logo", "has_questions", "has_salary_range",
    # categorical codes
    "employment_type_code", "required_experience_code", "required_education_code",
    "industry_code", "function_code",
    # lengths and missing indicators
    "company_profile_len", "missing_company_profile", "missing_description",
    "missing_requirements", "missing_benefits", "missing_salary",
    "missing_employment_type", "missing_industry", "missing_function",
)

#: Human-readable labels, used for SHAP drivers shown to people.
FEATURE_LABELS: dict[str, str] = {
    "word_count": "Posting length", "char_count": "Character count",
    "avg_sentence_len": "Average sentence length", "uppercase_ratio": "Capital-letter usage",
    "exclamation_count": "Exclamation marks", "punctuation_density": "Punctuation density",
    "red_flag_count": "Scam-style phrases", "flesch_reading_ease": "Reading ease",
    "fk_grade": "Reading grade level", "sentiment_compound": "Promotional tone",
    "email_count": "Email addresses", "personal_email_count": "Personal email addresses",
    "has_personal_email": "Personal email contact", "url_count": "Links in posting",
    "telecommuting": "Remote work", "has_company_logo": "Company logo",
    "has_questions": "Screening questions", "has_salary_range": "Salary range",
    "employment_type_code": "Employment type", "required_experience_code": "Experience level",
    "required_education_code": "Education level", "industry_code": "Industry",
    "function_code": "Job function", "company_profile_len": "Company profile length",
    "missing_company_profile": "No company profile", "missing_description": "No description",
    "missing_requirements": "No requirements", "missing_benefits": "No benefits listed",
    "missing_salary": "No salary information", "missing_employment_type": "No employment type",
    "missing_industry": "No industry", "missing_function": "No job function",
}


@dataclass
class ExtractedFeatures:
    """Everything derived from one posting; reused by rules and the model."""

    text: str
    numeric: dict[str, float]
    emails: list[str] = field(default_factory=list)
    personal_emails: list[str] = field(default_factory=list)
    urls: list[str] = field(default_factory=list)
    flag_hits: dict[str, list[str]] = field(default_factory=dict)  # group -> matched phrases
    pay_claims: list[str] = field(default_factory=list)
    shortener_urls: list[str] = field(default_factory=list)

    def vector(self) -> np.ndarray:
        return np.array([self.numeric[n] for n in NUMERIC_FEATURES], dtype=np.float32)


def extract_features(p: JobPosting) -> ExtractedFeatures:
    """Compute the complete feature set for one posting (O(total text length))."""
    text = combine_text(p)
    profile = clean_field(p.company_profile)

    words = _WORD_RE.findall(text)
    n_words = len(words)
    n_chars = len(text)
    sentences = [s for s in _SENT_SPLIT_RE.split(text) if s.strip()]
    letters = [c for c in text if c.isalpha()]

    uppercase_ratio = (sum(c.isupper() for c in letters) / len(letters)) if letters else 0.0
    punct_density = (sum(c in _PUNCT for c in text) / n_chars) if n_chars else 0.0

    fre, fkg = _readability(text, words, len(sentences)) if n_words >= 3 else (0.0, 0.0)

    sentiment = _vader.polarity_scores(text[: config.MAX_SENTIMENT_CHARS])["compound"] if text else 0.0

    emails = _EMAIL_RE.findall(text)
    personal = [e for e in emails if _email_domain(e) in config.PERSONAL_EMAIL_DOMAINS]
    urls = _URL_RE.findall(text)
    shorteners = []
    for u in urls:
        host = urlparse(u if "://" in u else f"http://{u}").hostname or ""
        if host.lower().removeprefix("www.") in config.URL_SHORTENERS:
            shorteners.append(u)

    flag_hits = {g: [m.lower() for m in pat.findall(text)] for g, pat in _FLAG_PATTERNS.items()}
    flag_hits = {g: hits for g, hits in flag_hits.items() if hits}
    pay_claims = [m.group(0) for m in _PAY_CLAIM_RE.finditer(text)]
    red_flag_count = sum(len(h) for h in flag_hits.values()) + len(pay_claims)

    numeric: dict[str, float] = {
        "word_count": n_words,
        "char_count": n_chars,
        "avg_sentence_len": (n_words / len(sentences)) if sentences else 0.0,
        "uppercase_ratio": uppercase_ratio,
        "exclamation_count": text.count("!"),
        "punctuation_density": punct_density,
        "red_flag_count": red_flag_count,
        "flesch_reading_ease": fre,
        "fk_grade": fkg,
        "sentiment_compound": sentiment,
        "email_count": len(emails),
        "personal_email_count": len(personal),
        "has_personal_email": float(bool(personal)),
        "url_count": len(urls),
        "telecommuting": float(p.telecommuting),
        "has_company_logo": float(p.has_company_logo),
        "has_questions": float(p.has_questions),
        "has_salary_range": float(bool(p.salary_range.strip())),
        "employment_type_code": _ordinal(p.employment_type, config.EMPLOYMENT_TYPES),
        "required_experience_code": _ordinal(p.required_experience, config.EXPERIENCE_LEVELS),
        "required_education_code": _ordinal(p.required_education, config.EDUCATION_LEVELS),
        "industry_code": _stable_bucket(p.industry),
        "function_code": _stable_bucket(p.function),
        "company_profile_len": len(profile),
        "missing_company_profile": float(not profile),
        "missing_description": float(not clean_field(p.description)),
        "missing_requirements": float(not clean_field(p.requirements)),
        "missing_benefits": float(not clean_field(p.benefits)),
        "missing_salary": float(not p.salary_range.strip()),
        "missing_employment_type": float(not p.employment_type.strip()),
        "missing_industry": float(not p.industry.strip()),
        "missing_function": float(not p.function.strip()),
    }
    return ExtractedFeatures(
        text=text, numeric={k: float(v) for k, v in numeric.items()},
        emails=emails, personal_emails=personal, urls=urls,
        flag_hits=flag_hits, pay_claims=pay_claims, shortener_urls=shorteners,
    )


def numeric_matrix(rows: list[ExtractedFeatures]) -> np.ndarray:
    """Stack numeric features in contract order -> (n_rows, len(NUMERIC_FEATURES))."""
    if not rows:
        return np.zeros((0, len(NUMERIC_FEATURES)), dtype=np.float32)
    return np.vstack([r.vector() for r in rows])


def make_tfidf_vectorizer() -> TfidfVectorizer:
    """Vectorizer factory with the settings the serving code assumes (training helper)."""
    return TfidfVectorizer(
        ngram_range=(1, 2), min_df=2, max_df=0.95, max_features=20_000,
        sublinear_tf=True, strip_accents="unicode", stop_words="english",
        dtype=np.float32,
    )
