"""Model artifacts: loading, probability scoring and SHAP explanations.

Expected files in MODELS_DIR (produced by the training job, not by this app):
    model.joblib       fitted classifier exposing predict_proba (e.g. XGBClassifier)
    vectorizer.joblib  fitted TfidfVectorizer (unigrams + bigrams)
    explainer.joblib   shap.TreeExplainer for the classifier
    meta.json          optional {"version": "...", "released": "..."}

SECURITY: joblib.load unpickles arbitrary objects. Only load artifacts from a
directory you control; never from user uploads or a world-writable location.

If any artifact is missing or incompatible the bundle reports loaded=False and
the pipeline falls back to the rule engine instead of crashing.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from scipy import sparse

from . import config
from .features import FEATURE_LABELS, NUMERIC_FEATURES

log = logging.getLogger(__name__)


@dataclass
class Contribution:
    """One feature's push on the risk score (SHAP value in log-odds)."""

    feature: str
    label: str
    value: float

    @property
    def raises_risk(self) -> bool:
        return self.value > 0


@dataclass
class ModelBundle:
    model: object | None = None
    vectorizer: object | None = None
    explainer: object | None = None
    version: str = "unavailable"
    released: str = ""
    loaded: bool = False
    explainer_ok: bool = False
    notes: list[str] = field(default_factory=list)
    feature_names: list[str] = field(default_factory=list)


def _inside(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def load_bundle(models_dir: Path | None = None) -> ModelBundle:
    """Load artifacts defensively. Never raises; inspect .loaded and .notes."""
    import joblib  # local import keeps module import cheap for rule-only use

    root = Path(models_dir or config.MODELS_DIR)
    bundle = ModelBundle()

    def read(name: str) -> object | None:
        path = root / name
        if not path.is_file() or not _inside(path, root):
            return None
        try:
            return joblib.load(path)
        except Exception as exc:  # noqa: BLE001
            log.warning("Could not load %s: %s", path, exc)
            bundle.notes.append(f"{name} could not be loaded")
            return None

    model = read(config.MODEL_FILE)
    vectorizer = read(config.VECTORIZER_FILE)
    if model is None or vectorizer is None:
        bundle.notes.append("Trained model files not found; using the rule engine only.")
        return bundle

    try:
        tfidf_names = [f"tfidf::{t}" for t in vectorizer.get_feature_names_out()]  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        bundle.notes.append("Vectorizer is not usable; using the rule engine only.")
        return bundle

    names = tfidf_names + list(NUMERIC_FEATURES)
    expected = getattr(model, "n_features_in_", None)
    if expected is not None and int(expected) != len(names):
        bundle.notes.append(
            f"Model expects {expected} features but the pipeline produces {len(names)}; "
            "retrain with features.NUMERIC_FEATURES. Using the rule engine only."
        )
        return bundle

    bundle.model, bundle.vectorizer, bundle.feature_names = model, vectorizer, names
    bundle.loaded = True

    explainer = read(config.EXPLAINER_FILE)
    if explainer is not None:
        bundle.explainer, bundle.explainer_ok = explainer, True
    else:
        bundle.notes.append("Explainer not found; risk drivers come from rules only.")

    meta_path = root / config.META_FILE
    if meta_path.is_file():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            bundle.version = str(meta.get("version", "unversioned"))
            bundle.released = str(meta.get("released", ""))
        except (OSError, ValueError):
            bundle.version = "unversioned"
    else:
        bundle.version = "unversioned"
    return bundle


# ---------------------------------------------------------------------------
# Inference
# ---------------------------------------------------------------------------
def build_matrix(bundle: ModelBundle, texts: list[str], numeric: np.ndarray) -> sparse.csr_matrix:
    """[TF-IDF | numeric] as one CSR matrix."""
    tfidf = bundle.vectorizer.transform(texts)  # type: ignore[union-attr]
    return sparse.hstack([tfidf, sparse.csr_matrix(numeric)], format="csr", dtype=np.float32)


def predict_proba(bundle: ModelBundle, matrix: sparse.csr_matrix) -> np.ndarray:
    """P(fraudulent) per row. Cost: one sparse transform + one tree-ensemble pass."""
    return np.asarray(bundle.model.predict_proba(matrix))[:, 1]  # type: ignore[union-attr]


def _label_for(name: str) -> str:
    if name.startswith("tfidf::"):
        return f"Wording: “{name[7:]}”"
    return FEATURE_LABELS.get(name, name.replace("_", " ").capitalize())


def explain_row(bundle: ModelBundle, matrix: sparse.csr_matrix, top_k: int = 8) -> list[Contribution]:
    """Top SHAP contributions for a single row; [] if no explainer or on failure."""
    if not (bundle.loaded and bundle.explainer_ok):
        return []
    try:
        dense = matrix.toarray()  # one row only: cheap even with 20k TF-IDF columns
        values = bundle.explainer.shap_values(dense)  # type: ignore[union-attr]
        if isinstance(values, list):  # older shap: one array per class
            values = values[-1]
        row = np.asarray(values).reshape(-1)
        if row.shape[0] != len(bundle.feature_names):
            return []
        idx = np.argsort(-np.abs(row))[:top_k]
        return [
            Contribution(bundle.feature_names[i], _label_for(bundle.feature_names[i]), float(row[i]))
            for i in idx
            if row[i] != 0.0
        ]
    except Exception as exc:  # noqa: BLE001 - explanations must never break screening
        log.warning("SHAP explanation failed: %s", exc)
        return []


def global_importance(bundle: ModelBundle, top_k: int = 12) -> list[tuple[str, float]]:
    """Normalised model-wide feature importance (label, share), if exposed by the model."""
    imp = getattr(bundle.model, "feature_importances_", None)
    if not bundle.loaded or imp is None:
        return []
    imp = np.asarray(imp, dtype=float)
    if imp.shape[0] != len(bundle.feature_names) or imp.sum() <= 0:
        return []
    imp = imp / imp.sum()
    idx = np.argsort(-imp)[:top_k]
    return [(_label_for(bundle.feature_names[i]), float(imp[i])) for i in idx]
