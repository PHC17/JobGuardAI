"""Screening pipeline: features -> rules -> ML -> fusion -> level -> recommendations."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Sequence

import numpy as np
import pandas as pd

from . import config, model as model_mod
from .features import ExtractedFeatures, JobPosting, extract_features, numeric_matrix
from .model import Contribution, ModelBundle
from .recommendations import Recommendation, build_recommendations, headline_for
from .risk import RiskBands, bands_from_threshold, level_for
from .rules import RuleHit, evaluate


@dataclass(frozen=True)
class ScreeningConfig:
    bands: RiskBands = field(default_factory=lambda: bands_from_threshold(0.55))
    ml_weight: float = 0.65          # share of the ML probability in the blended score
    audience: str = "job_seeker"     # job_seeker | recruiter


@dataclass
class ScreeningResult:
    score: float                      # fused risk, 0-1
    level: str
    heuristic_score: float
    ml_probability: float | None
    rule_hits: tuple[RuleHit, ...]
    contributions: list[Contribution]
    recommendations: list[Recommendation]
    headline: str
    engine: str                       # "hybrid" | "rules"
    features: dict[str, float]


def fuse_scores(ml: float | None, heuristic: float, ml_weight: float = 0.65) -> float:
    """Blend the ML probability with the heuristic score.

    - No model: the heuristic score stands alone.
    - Otherwise a weighted average, except that a very confident signal from
      either side (>= 0.85) cannot be diluted below 85% of its own value. This
      stops a clean-looking text from hiding an explicit payment request, and
      stops a weak rule set from hiding a strongly fraudulent text pattern.
    """
    if ml is None:
        return float(np.clip(heuristic, 0.0, 1.0))
    w = float(np.clip(ml_weight, 0.0, 1.0))
    blended = w * ml + (1.0 - w) * heuristic
    anchor = max(ml, heuristic)
    if anchor >= 0.85:
        blended = max(blended, 0.85 * anchor)
    return float(np.clip(blended, 0.0, 1.0))


class ScreeningPipeline:
    def __init__(self, bundle: ModelBundle) -> None:
        self.bundle = bundle

    @property
    def engine(self) -> str:
        return "hybrid" if self.bundle.loaded else "rules"

    # -- single posting -----------------------------------------------------
    def screen(self, posting: JobPosting, cfg: ScreeningConfig | None = None, explain: bool = True) -> ScreeningResult:
        cfg = cfg or ScreeningConfig()
        feats = extract_features(posting)
        rules = evaluate(posting, feats)

        ml_prob: float | None = None
        contributions: list[Contribution] = []
        if self.bundle.loaded:
            matrix = model_mod.build_matrix(self.bundle, [feats.text], numeric_matrix([feats]))
            ml_prob = float(model_mod.predict_proba(self.bundle, matrix)[0])
            if explain:
                contributions = model_mod.explain_row(self.bundle, matrix)

        score = fuse_scores(ml_prob, rules.score, cfg.ml_weight)
        level = level_for(score, cfg.bands)
        return ScreeningResult(
            score=score, level=level, heuristic_score=rules.score, ml_probability=ml_prob,
            rule_hits=rules.hits, contributions=contributions,
            recommendations=build_recommendations(level, rules.hits, contributions, cfg.audience),
            headline=headline_for(level, cfg.audience), engine=self.engine, features=feats.numeric,
        )

    # -- many postings ------------------------------------------------------
    def screen_many(
        self,
        postings: Sequence[JobPosting],
        cfg: ScreeningConfig | None = None,
        progress: Callable[[float], None] | None = None,
    ) -> list[ScreeningResult]:
        """Batch screening without SHAP.

        Complexity: O(N * L) feature extraction (L = text length) plus a single
        sparse TF-IDF transform and one tree-ensemble pass, instead of N model
        calls. SHAP is skipped on purpose: it dominates cost at scale.
        """
        cfg = cfg or ScreeningConfig()
        n = len(postings)
        feats: list[ExtractedFeatures] = []
        for i, p in enumerate(postings):
            feats.append(extract_features(p))
            if progress and (i % 25 == 0 or i == n - 1):
                progress(0.8 * (i + 1) / max(n, 1))

        probs: np.ndarray | None = None
        if self.bundle.loaded and n:
            matrix = model_mod.build_matrix(self.bundle, [f.text for f in feats], numeric_matrix(feats))
            probs = model_mod.predict_proba(self.bundle, matrix)

        results: list[ScreeningResult] = []
        for i, (p, f) in enumerate(zip(postings, feats)):
            rules = evaluate(p, f)
            ml = float(probs[i]) if probs is not None else None
            score = fuse_scores(ml, rules.score, cfg.ml_weight)
            level = level_for(score, cfg.bands)
            results.append(ScreeningResult(
                score=score, level=level, heuristic_score=rules.score, ml_probability=ml,
                rule_hits=rules.hits, contributions=[],
                recommendations=[], headline=headline_for(level, cfg.audience),
                engine=self.engine, features=f.numeric,
            ))
        if progress:
            progress(1.0)
        return results


# ---------------------------------------------------------------------------
# Batch helpers
# ---------------------------------------------------------------------------
def postings_from_frame(df: pd.DataFrame) -> list[JobPosting]:
    if len(df) > config.MAX_BATCH_ROWS:
        raise ValueError(f"A single batch can contain at most {config.MAX_BATCH_ROWS:,} rows.")
    return [JobPosting.from_mapping(r) for r in df.to_dict(orient="records")]


def results_to_frame(df: pd.DataFrame, results: Sequence[ScreeningResult]) -> pd.DataFrame:
    """Result table: one row per posting, safe to display."""
    titles = df["title"].fillna("").astype(str) if "title" in df.columns else pd.Series([""] * len(df))
    companies = (
        df["company_profile"].fillna("").astype(str).str.slice(0, 60)
        if "company_profile" in df.columns else pd.Series([""] * len(df))
    )
    out = pd.DataFrame({
        "row": np.arange(1, len(results) + 1),
        "title": titles.str.slice(0, 90).to_numpy(),
        "company": companies.to_numpy(),
        "risk_score": [round(r.score * 100) for r in results],
        "risk_level": [r.level for r in results],
        "top_signals": ["; ".join(h.label for h in r.rule_hits[:3]) for r in results],
        "recommended_action": [r.headline for r in results],
    })
    return out


def sanitize_for_csv(df: pd.DataFrame) -> pd.DataFrame:
    """Neutralise spreadsheet formula injection (cells starting with = + - @) before export."""
    safe = df.copy()
    for col in safe.columns:  # dtype-agnostic: works for object and pandas string dtypes
        safe[col] = safe[col].map(
            lambda v: "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@", "\t", "\r") else v
        )
    return safe
