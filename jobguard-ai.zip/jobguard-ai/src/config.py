"""Central configuration: paths, limits and red-flag vocabularies.

Everything here is plain data so the engine stays framework-free and testable.
"""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = Path(os.environ.get("JOBGUARD_MODELS_DIR", BASE_DIR / "models")).resolve()
ASSETS_DIR = BASE_DIR / "assets"

# Artifact file names expected inside MODELS_DIR.
MODEL_FILE = "model.joblib"
VECTORIZER_FILE = "vectorizer.joblib"
EXPLAINER_FILE = "explainer.joblib"
META_FILE = "meta.json"  # optional: {"version": "...", "released": "..."}

# ---------------------------------------------------------------------------
# Input limits (denial-of-service guards)
# ---------------------------------------------------------------------------
MAX_FIELD_CHARS = 50_000        # per text field
MAX_SENTIMENT_CHARS = 20_000    # VADER cost grows with length
MAX_BATCH_ROWS = 5_000
MAX_CSV_MB = 10
MAX_DOC_MB = 5                  # uploaded .pdf / .docx / .txt
MAX_PDF_PAGES = 30
MAX_DOCX_UNCOMPRESSED_MB = 50   # zip-bomb guard
MAX_FETCH_BYTES = 1_500_000     # fetched web page
FETCH_TIMEOUT = (5, 10)         # connect, read (seconds)
MAX_REDIRECTS = 3

# ---------------------------------------------------------------------------
# Contact / link vocabularies
# ---------------------------------------------------------------------------
PERSONAL_EMAIL_DOMAINS = frozenset({
    "gmail.com", "googlemail.com", "yahoo.com", "yahoo.in", "yahoo.co.in",
    "ymail.com", "hotmail.com", "outlook.com", "live.com", "msn.com",
    "aol.com", "icloud.com", "me.com", "proton.me", "protonmail.com",
    "mail.com", "gmx.com", "zoho.com", "rediffmail.com", "yandex.com",
})

URL_SHORTENERS = frozenset({
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "cutt.ly", "rb.gy", "shorturl.at", "tiny.cc", "rebrand.ly",
})

# ---------------------------------------------------------------------------
# Red-flag phrase groups. Matching is case-insensitive on word boundaries.
# ---------------------------------------------------------------------------
RED_FLAG_GROUPS: dict[str, tuple[str, ...]] = {
    "advance_fee": (
        "registration fee", "training fee", "processing fee", "application fee",
        "security deposit", "refundable deposit", "starter kit", "equipment fee",
        "wire transfer", "western union", "moneygram", "gift card", "itunes card",
        "bitcoin", "crypto payment", "cashier's check", "cashiers check",
        "send money", "deposit a check", "purchase equipment", "reimburse you",
        "pay a fee", "pay for your",
    ),
    "identity_harvest": (
        "social security", "ssn", "bank account", "account number",
        "routing number", "passport copy", "copy of your passport",
        "scan of your id", "copy of your id", "driver's license",
        "credit card", "debit card", "one-time password", "otp",
        "aadhaar", "aadhar", "pan card", "date of birth",
    ),
    "off_platform": (
        "whatsapp", "telegram", "signal app", "wechat", "text us",
        "skype interview", "google hangouts", "contact us on",
    ),
    "unrealistic_pay": (
        "guaranteed income", "no experience needed", "no experience required",
        "make money fast", "easy money", "unlimited earning", "financial freedom",
        "be your own boss", "passive income", "earn from home", "earn up to",
        "high salary for", "get paid daily",
    ),
    "urgency": (
        "urgent hiring", "urgently hiring", "hiring immediately",
        "start immediately", "apply immediately", "limited slots",
        "limited openings", "limited positions", "act now", "apply today",
        "last chance", "asap",
    ),
    "interview_bypass": (
        "no interview", "interview via chat", "chat interview", "text interview",
        "instant hiring", "hired instantly", "you are hired", "no resume",
        "no cv", "interview on whatsapp", "interview on telegram",
    ),
    "high_risk_role": (
        "data entry", "online typist", "typing job", "copy paste", "form filling",
        "ad posting", "package handler", "mystery shopper", "reshipping",
        "payment processor", "money transfer agent", "survey jobs",
    ),
}

# Pay-claim pattern, e.g. "earn $500 per day". Bounded quantifiers keep it linear.
PAY_CLAIM_PATTERN = (
    r"(?:earn|make|get paid|income of)[^.\n]{0,40}?[\$₹€£]\s?\d[\d,]{2,}"
    r"[^.\n]{0,20}?(?:per|a|/|each)\s?(?:day|week|hour)"
)

# ---------------------------------------------------------------------------
# Categorical vocabularies (ordinal codes; 0 = missing/unknown)
# ---------------------------------------------------------------------------
EMPLOYMENT_TYPES = ("Full-time", "Part-time", "Contract", "Temporary", "Other")
EXPERIENCE_LEVELS = (
    "Internship", "Entry level", "Associate", "Mid-Senior level",
    "Director", "Executive", "Not Applicable",
)
EDUCATION_LEVELS = (
    "High School or equivalent", "Some College Coursework Completed",
    "Vocational", "Certification", "Associate Degree", "Bachelor's Degree",
    "Master's Degree", "Doctorate", "Professional", "Unspecified",
)
HASH_BUCKETS = 128  # industry / function are open vocabularies -> stable hash bucket
