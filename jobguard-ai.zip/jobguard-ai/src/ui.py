"""Presentation helpers: theme, risk gauge, badges and chart styling.

All HTML here is built from trusted templates. Any text that originates from a
posting, file or URL MUST go through esc() before being interpolated.
"""
from __future__ import annotations

import base64
import html as _html
import math
from functools import lru_cache

import streamlit as st

from . import config
from .risk import RiskBands

# 8px spacing scale
S1, S2, S3, S4 = 8, 16, 24, 32

PALETTES: dict[str, dict[str, str]] = {
    "dark": {
        "bg": "#0B1020", "surface": "#111A2E", "surface2": "#16213A", "border": "#243049",
        "text": "#E6EAF2", "muted": "#8E9BB5", "accent": "#3B82F6", "accent_soft": "rgba(59,130,246,.14)",
        "shadow": "0 1px 2px rgba(0,0,0,.35), 0 8px 24px rgba(2,6,23,.35)",
        "Low": "#34D399", "Medium": "#FBBF24", "High": "#FB7185", "Critical": "#F43F5E",
        "track": "#1C2842",
    },
    "light": {
        "bg": "#F4F6FB", "surface": "#FFFFFF", "surface2": "#F0F3FA", "border": "#DCE2EE",
        "text": "#0F172A", "muted": "#5B6578", "accent": "#2563EB", "accent_soft": "rgba(37,99,235,.10)",
        "shadow": "0 1px 2px rgba(15,23,42,.06), 0 8px 24px rgba(15,23,42,.06)",
        "Low": "#059669", "Medium": "#B7791F", "High": "#E11D48", "Critical": "#BE123C",
        "track": "#E3E8F3",
    },
}


def esc(value: object) -> str:
    """HTML-escape untrusted text.

    Whitespace is collapsed (the HTML compactor joins lines) and '$' becomes an
    entity so Streamlit's Markdown never treats pay amounts as LaTeX math.
    """
    flat = " ".join(str(value).split())
    return _html.escape(flat, quote=True).replace("$", "&#36;")


def theme_mode() -> str:
    from .app_state import pv  # local import: app_state does not import ui
    return "light" if pv("s_theme") == "Light" else "dark"


def palette() -> dict[str, str]:
    return PALETTES[theme_mode()]


def level_color(level: str) -> str:
    return palette().get(level, palette()["muted"])


def _compact(markup: str) -> str:
    """Remove indentation/newlines so Markdown never turns the HTML into a code block."""
    return "".join(line.strip() for line in markup.splitlines())


def html(markup: str) -> None:
    st.markdown(_compact(markup), unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Agent artwork
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def agent_uri() -> str:
    svg = (config.ASSETS_DIR / "agent.svg").read_bytes()
    return "data:image/svg+xml;base64," + base64.b64encode(svg).decode("ascii")


# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------
def inject_theme() -> None:
    p = palette()
    css = f"""
<style>
:root {{
  --jg-bg:{p['bg']}; --jg-surface:{p['surface']}; --jg-surface2:{p['surface2']}; --jg-border:{p['border']};
  --jg-text:{p['text']}; --jg-muted:{p['muted']}; --jg-accent:{p['accent']}; --jg-accent-soft:{p['accent_soft']};
  --jg-shadow:{p['shadow']}; --jg-track:{p['track']};
  --jg-low:{p['Low']}; --jg-medium:{p['Medium']}; --jg-high:{p['High']}; --jg-critical:{p['Critical']};
  --s1:8px; --s2:16px; --s3:24px; --s4:32px;
}}
html, body, .stApp, .stApp p, .stApp label, .stApp button, .stApp input, .stApp textarea, .stApp li, .stApp h1, .stApp h2, .stApp h3 {{
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI Variable", "Segoe UI", Inter, Roboto, "Helvetica Neue", Arial, sans-serif;
}}
/* never override the icon font */
[data-testid="stIconMaterial"], .material-symbols-rounded, [class*="material-symbols"] {{
  font-family: "Material Symbols Rounded", "Material Symbols Outlined" !important;
}}
.stApp {{ background: var(--jg-bg); color: var(--jg-text); }}
[data-testid="stHeader"] {{ background: transparent; }}
.block-container {{ padding-top: var(--s4); padding-bottom: calc(var(--s4) * 2); max-width: 1240px; }}
h1, h2, h3, h4 {{ color: var(--jg-text); letter-spacing: -0.01em; }}
p, label, li, span, .stMarkdown {{ color: var(--jg-text); }}
[data-testid="stCaptionContainer"], .jg-muted {{ color: var(--jg-muted) !important; }}

/* sidebar */
[data-testid="stSidebar"] {{ background: var(--jg-surface); border-right: 1px solid var(--jg-border); }}
[data-testid="stSidebarNav"] a, [data-testid="stSidebar"] a {{ border-radius: 8px; }}
[data-testid="stSidebarNav"] a[aria-current="page"] {{ background: var(--jg-accent-soft); }}

/* cards: st.container(key="card_*") */
[class*="st-key-card_"] {{
  background: var(--jg-surface); border: 1px solid var(--jg-border); border-radius: 14px;
  padding: var(--s3); box-shadow: var(--jg-shadow);
}}
[class*="st-key-card_"] > div {{ gap: var(--s2); }}
.st-key-results_panel {{ position: sticky; top: var(--s3); }}

/* inputs */
.stTextInput input, .stTextArea textarea, .stNumberInput input {{
  background: var(--jg-surface2) !important; color: var(--jg-text) !important;
  border: 1px solid var(--jg-border) !important; border-radius: 10px !important;
}}
.stTextInput input:focus, .stTextArea textarea:focus {{ border-color: var(--jg-accent) !important; box-shadow: 0 0 0 3px var(--jg-accent-soft) !important; }}
[data-baseweb="select"] > div {{ background: var(--jg-surface2) !important; border: 1px solid var(--jg-border) !important; border-radius: 10px !important; color: var(--jg-text) !important; }}
[data-baseweb="popover"] [role="listbox"], [data-baseweb="popover"] ul {{ background: var(--jg-surface) !important; color: var(--jg-text) !important; }}
[data-testid="stFileUploaderDropzone"] {{ background: var(--jg-surface2); border: 1px dashed var(--jg-border); border-radius: 12px; }}
[data-testid="stFileUploaderDropzone"] * {{ color: var(--jg-muted); }}
[data-testid="stForm"] {{ border: none; padding: 0; }}

[data-baseweb="input"], [data-baseweb="textarea"], [data-baseweb="base-input"] {{
  background: var(--jg-surface2) !important; border-color: var(--jg-border) !important; border-radius: 10px !important;
}}
.stTextInput input::placeholder, .stTextArea textarea::placeholder {{ color: var(--jg-muted) !important; opacity: .75; }}
[data-testid="stSidebarNav"] a span, [data-testid="stSidebarNav"] a {{ color: var(--jg-text) !important; }}
[data-testid="stSidebarNav"] a [data-testid="stIconMaterial"] {{ color: var(--jg-muted) !important; }}
[data-testid="stSidebarCollapseButton"] * , [data-testid="stSidebarCollapsedControl"] * {{ color: var(--jg-muted) !important; }}
[data-testid="stToggle"] label p, [data-baseweb="segmented-control"] * {{ color: var(--jg-text); }}

/* buttons */
.stButton > button, .stDownloadButton > button, [data-testid="stFormSubmitButton"] > button {{
  border-radius: 10px; font-weight: 600; min-height: 44px; transition: background .15s, border-color .15s;
  border: 1px solid var(--jg-border); background: var(--jg-surface2); color: var(--jg-text);
}}
.stButton > button:hover, .stDownloadButton > button:hover, [data-testid="stFormSubmitButton"] > button:hover {{ border-color: var(--jg-accent); color: var(--jg-text); }}
button[kind="primary"], button[kind="primaryFormSubmit"] {{
  background: var(--jg-accent) !important; border-color: var(--jg-accent) !important; color: #fff !important;
}}
button[kind="primary"]:hover, button[kind="primaryFormSubmit"]:hover {{ filter: brightness(1.08); }}
button:focus-visible {{ outline: 2px solid var(--jg-accent); outline-offset: 2px; }}

/* tabs / expanders */
[data-baseweb="tab-list"] {{ gap: var(--s1); border-bottom: 1px solid var(--jg-border); }}
[data-baseweb="tab"] {{ color: var(--jg-muted); }}
[data-baseweb="tab"][aria-selected="true"] {{ color: var(--jg-text); }}
[data-testid="stExpander"] {{ background: var(--jg-surface2); border: 1px solid var(--jg-border); border-radius: 12px; }}
[data-testid="stExpander"] summary {{ font-weight: 600; }}
[data-testid="stDataFrame"] {{ border: 1px solid var(--jg-border); border-radius: 12px; overflow: hidden; }}
hr {{ border-color: var(--jg-border); }}

/* components */
.jg-hero {{ display:flex; align-items:center; justify-content:space-between; gap:var(--s3);
  background: linear-gradient(135deg, var(--jg-surface) 0%, var(--jg-surface2) 100%);
  border:1px solid var(--jg-border); border-radius:16px; padding: var(--s3) var(--s4); box-shadow: var(--jg-shadow);
  margin-bottom: var(--s3); overflow:hidden; }}
.jg-hero h1 {{ margin:0 0 var(--s1) 0; font-size: 1.85rem; font-weight: 650; }}
.jg-hero p {{ margin:0; color: var(--jg-muted); max-width: 52ch; line-height: 1.55; }}
.jg-hero img {{ height: 148px; margin: -8px 0 -24px 0; flex-shrink:0; }}
.jg-title {{ font-size: 1.05rem; font-weight: 650; margin: 0 0 var(--s1) 0; }}
.jg-sub {{ color: var(--jg-muted); font-size: .9rem; line-height:1.5; margin:0; }}
.jg-brand {{ display:flex; align-items:center; gap:12px; padding: var(--s1) 0 var(--s2) 0; }}
.jg-brand img {{ width:44px; height:44px; border-radius:12px; background:#070B16; object-fit:cover; object-position:50% 20%; border:1px solid var(--jg-border); }}
.jg-brand b {{ display:block; font-size:1.05rem; letter-spacing:-.01em; }}
.jg-brand span {{ color: var(--jg-muted); font-size:.8rem; }}
.jg-badge {{ display:inline-block; padding: 4px 12px; border-radius: 999px; font-size:.82rem; font-weight:650; border:1px solid; }}
.jg-gauge {{ display:flex; flex-direction:column; align-items:center; gap: var(--s1); padding: var(--s1) 0; }}
.jg-gauge svg {{ overflow: visible; }}
.jg-ring {{ stroke-dasharray: var(--c); stroke-dashoffset: var(--off); animation: jg-fill .9s cubic-bezier(.2,.7,.2,1) both; }}
@keyframes jg-fill {{ from {{ stroke-dashoffset: var(--c); }} to {{ stroke-dashoffset: var(--off); }} }}
@media (prefers-reduced-motion: reduce) {{ .jg-ring {{ animation: none; }} }}
.jg-verdict {{ text-align:center; font-weight:650; font-size:1.1rem; margin:0; }}
.jg-item {{ display:flex; gap:12px; padding: 12px 0; border-top: 1px solid var(--jg-border); }}
.jg-item:first-child {{ border-top: none; padding-top: 0; }}
.jg-dot {{ width:10px; height:10px; border-radius:50%; margin-top:6px; flex-shrink:0; }}
.jg-item b {{ display:block; font-weight:650; }}
.jg-item small {{ color: var(--jg-muted); display:block; line-height:1.5; }}
.jg-chip {{ display:inline-block; background: var(--jg-surface2); border:1px solid var(--jg-border); border-radius:8px; padding:2px 8px; margin: 6px 6px 0 0; font-size:.78rem; color: var(--jg-muted); max-width:100%; overflow-wrap:anywhere; }}
.jg-empty {{ text-align:center; padding: var(--s3) var(--s2); }}
.jg-empty img {{ width: 180px; opacity:.92; }}
.jg-tile {{ background: var(--jg-surface); border:1px solid var(--jg-border); border-radius:14px; padding: var(--s2) var(--s3); box-shadow: var(--jg-shadow); }}
.jg-tile .v {{ font-size:2rem; font-weight:650; line-height:1.1; font-variant-numeric: tabular-nums; }}
.jg-tile .l {{ color: var(--jg-muted); font-size:.85rem; margin-top:4px; }}
.jg-bandbar {{ display:flex; height:14px; border-radius:999px; overflow:hidden; border:1px solid var(--jg-border); }}
.jg-bandbar div {{ height:100%; }}
.jg-kv {{ display:flex; justify-content:space-between; gap:var(--s2); padding:10px 0; border-top:1px solid var(--jg-border); }}
.jg-kv:first-of-type {{ border-top:none; }}
.jg-kv span:first-child {{ color: var(--jg-muted); }}
@media (max-width: 768px) {{ .jg-hero {{ flex-direction: column-reverse; align-items:flex-start; padding: var(--s3); }} .jg-hero img {{ height:110px; margin:0; }} .st-key-results_panel {{ position: static; }} }}
</style>
"""
    st.markdown(css, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Components
# ---------------------------------------------------------------------------
def sidebar_brand() -> None:
    with st.sidebar:
        html(f"""
        <div class="jg-brand"><img src="{agent_uri()}" alt="">
        <div><b>JobGuard AI</b><span>Posting risk screening</span></div></div>
        """)


def page_header(title: str, subtitle: str, with_agent: bool = False) -> None:
    img = f'<img src="{agent_uri()}" alt="">' if with_agent else ""
    html(f'<div class="jg-hero"><div><h1>{esc(title)}</h1><p>{esc(subtitle)}</p></div>{img}</div>')


def section_title(title: str, sub: str = "") -> None:
    sub_html = f'<p class="jg-sub">{esc(sub)}</p>' if sub else ""
    html(f'<p class="jg-title">{esc(title)}</p>{sub_html}')


def badge(level: str) -> str:
    c = level_color(level)
    return (f'<span class="jg-badge" style="color:{c};border-color:{c}55;background:{c}1F">{esc(level)} risk</span>')


def metric_tile(label: str, value: str, color: str | None = None) -> str:
    style = f' style="color:{color}"' if color else ""
    return f'<div class="jg-tile"><div class="v"{style}>{esc(value)}</div><div class="l">{esc(label)}</div></div>'


def gauge(score: float, level: str, bands: RiskBands, size: int = 240) -> None:
    """Circular risk gauge with tick marks at the Medium/High/Critical boundaries."""
    p = palette()
    color = p[level]
    cx = cy = size / 2
    r = size / 2 - 26
    stroke = 16
    circ = 2 * math.pi * r
    off = circ * (1 - min(max(score, 0.0), 1.0))

    ticks = ""
    for b in (bands.medium, bands.high, bands.critical):
        a = b * 2 * math.pi
        x1, y1 = cx + (r + stroke / 2 + 3) * math.sin(a), cy - (r + stroke / 2 + 3) * math.cos(a)
        x2, y2 = cx + (r + stroke / 2 + 10) * math.sin(a), cy - (r + stroke / 2 + 10) * math.cos(a)
        ticks += f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{p["muted"]}" stroke-width="2" stroke-linecap="round"/>'

    html(f"""
    <div class="jg-gauge" role="img" aria-label="Risk score {round(score * 100)} out of 100, {esc(level)} risk">
    <svg width="{size}" height="{size}" viewBox="0 0 {size} {size}">
      <circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{p['track']}" stroke-width="{stroke}"/>
      <circle class="jg-ring" cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{color}" stroke-width="{stroke}"
        stroke-linecap="round" transform="rotate(-90 {cx} {cy})"
        style="--c:{circ:.2f};--off:{off:.2f};filter:drop-shadow(0 0 8px {color}66)"/>
      {ticks}
      <text x="{cx}" y="{cy + 8}" text-anchor="middle" font-size="58" font-weight="650" fill="{p['text']}"
        style="font-variant-numeric:tabular-nums">{round(score * 100)}</text>
      <text x="{cx}" y="{cy + 34}" text-anchor="middle" font-size="13" fill="{p['muted']}">out of 100</text>
    </svg>{badge(level)}</div>
    """)


def band_bar(bands: RiskBands) -> str:
    p = palette()
    segs = [
        (bands.medium, p["Low"]), (bands.high - bands.medium, p["Medium"]),
        (bands.critical - bands.high, p["High"]), (1 - bands.critical, p["Critical"]),
    ]
    return '<div class="jg-bandbar">' + "".join(
        f'<div style="width:{w * 100:.2f}%;background:{c}"></div>' for w, c in segs
    ) + "</div>"


def style_figure(fig, height: int = 320):
    """Apply the product chart style: transparent surface, recessive grid, text in ink tokens."""
    p = palette()
    fig.update_layout(
        height=height, margin=dict(l=8, r=8, t=8, b=8), paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", font=dict(color=p["text"], size=13),
        hoverlabel=dict(bgcolor=p["surface"], bordercolor=p["border"], font=dict(color=p["text"])),
        showlegend=False,
    )
    fig.update_xaxes(gridcolor=p["border"], zerolinecolor=p["border"], linecolor=p["border"], tickfont=dict(color=p["muted"]))
    fig.update_yaxes(gridcolor="rgba(0,0,0,0)", linecolor=p["border"], tickfont=dict(color=p["text"]))
    return fig
