"""Bring postings in from files and links.

Security notes
- Uploads: extension allowlist, size caps, page caps and a zip-bomb check for .docx.
- URLs: SSRF protection. Only http/https on ports 80/443, no credentials in the
  URL, every resolved address must be globally routable (blocks localhost,
  private ranges, link-local/cloud-metadata, etc.), redirects are followed
  manually and re-validated at each hop, and the body is size- and
  time-limited.
  Residual risk: DNS rebinding between validation and connect. For hostile
  environments also enforce egress rules at the network layer.
"""
from __future__ import annotations

import io
import ipaddress
import json
import re
import socket
import zipfile
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from . import config


class IngestError(ValueError):
    """User-presentable ingestion failure (message is safe to show)."""


@dataclass
class ImportedPosting:
    """Fields to prefill the screening form. Empty strings mean 'not found'."""

    title: str = ""
    company_profile: str = ""
    description: str = ""
    requirements: str = ""
    salary_range: str = ""
    employment_type: str = ""
    industry: str = ""
    telecommuting: bool = False
    source: str = ""
    notes: list[str] = field(default_factory=list)


_WS = re.compile(r"[ \t\r\f\v]+")
_NL = re.compile(r"\n{3,}")


def _tidy(text: str) -> str:
    text = _WS.sub(" ", text.replace(" ", " "))
    return _NL.sub("\n\n", text).strip()[: config.MAX_FIELD_CHARS]


# ---------------------------------------------------------------------------
# Files
# ---------------------------------------------------------------------------
ALLOWED_EXTENSIONS = (".txt", ".md", ".pdf", ".docx")


def extract_text_from_file(filename: str, data: bytes) -> str:
    name = (filename or "").lower()
    if not name.endswith(ALLOWED_EXTENSIONS):
        raise IngestError("Unsupported file type. Upload a .txt, .md, .pdf or .docx file.")
    if len(data) > config.MAX_DOC_MB * 1024 * 1024:
        raise IngestError(f"File is larger than {config.MAX_DOC_MB} MB.")
    if not data:
        raise IngestError("The file is empty.")

    if name.endswith((".txt", ".md")):
        text = data.decode("utf-8", errors="replace")
    elif name.endswith(".pdf"):
        text = _pdf_text(data)
    else:
        text = _docx_text(data)

    text = _tidy(text)
    if len(text) < 20:
        raise IngestError("No readable text was found. Scanned files need to be converted to text first.")
    return text


def _pdf_text(data: bytes) -> str:
    from pypdf import PdfReader

    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            raise IngestError("This PDF is password protected.")
        pages = reader.pages[: config.MAX_PDF_PAGES]
        return "\n".join((p.extract_text() or "") for p in pages)
    except IngestError:
        raise
    except Exception as exc:  # noqa: BLE001 - parser errors vary widely
        raise IngestError("The PDF could not be read.") from exc


def _docx_text(data: bytes) -> str:
    import docx  # python-docx

    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            total = sum(i.file_size for i in zf.infolist())
        if total > config.MAX_DOCX_UNCOMPRESSED_MB * 1024 * 1024:
            raise IngestError("The document expands to an unsafe size.")
        document = docx.Document(io.BytesIO(data))
        parts = [p.text for p in document.paragraphs]
        for table in document.tables:
            for row in table.rows:
                parts.extend(cell.text for cell in row.cells)
        return "\n".join(parts)
    except IngestError:
        raise
    except Exception as exc:  # noqa: BLE001
        raise IngestError("The Word document could not be read.") from exc


def posting_from_text(text: str, source: str) -> ImportedPosting:
    """Plain text goes into the description; a short first line becomes the title."""
    first = text.split("\n", 1)[0].strip()
    title = first if 3 <= len(first) <= 100 else ""
    return ImportedPosting(title=title, description=text, source=source)


# ---------------------------------------------------------------------------
# Links
# ---------------------------------------------------------------------------
def validate_public_url(url: str) -> str:
    """Return a normalised URL or raise IngestError if it could reach internal resources."""
    url = (url or "").strip()
    if len(url) > 2048:
        raise IngestError("The link is too long.")
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise IngestError("Enter a link that starts with http:// or https://.")
    if parsed.username or parsed.password:
        raise IngestError("Links containing a username or password are not supported.")
    host = parsed.hostname
    if not host:
        raise IngestError("The link has no website address.")
    try:
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
    except ValueError as exc:
        raise IngestError("The link has an invalid port.") from exc
    if port not in (80, 443):
        raise IngestError("Only standard web ports are supported.")

    try:
        infos = socket.getaddrinfo(host, port, proto=socket.IPPROTO_TCP)
    except socket.gaierror as exc:
        raise IngestError("That website address could not be found.") from exc
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not ip.is_global:
            raise IngestError("That address points to a private or internal network and cannot be fetched.")
    return url


def fetch_job_page(url: str) -> ImportedPosting:
    """Fetch and parse a public job page (schema.org JobPosting first, visible text as fallback)."""
    current = validate_public_url(url)
    headers = {"User-Agent": "JobGuardAI/1.0 (+posting screening)", "Accept": "text/html,text/plain;q=0.8"}
    session = requests.Session()
    session.trust_env = False  # ignore ambient proxy settings for user-supplied URLs

    for _ in range(config.MAX_REDIRECTS + 1):
        try:
            resp = session.get(current, headers=headers, timeout=config.FETCH_TIMEOUT,
                               allow_redirects=False, stream=True)
        except requests.RequestException as exc:
            raise IngestError("The page could not be reached. Check the link or paste the text instead.") from exc
        with resp:
            if resp.is_redirect or resp.is_permanent_redirect:
                location = resp.headers.get("Location")
                if not location:
                    raise IngestError("The page redirected without a destination.")
                current = validate_public_url(urljoin(current, location))
                continue
            if resp.status_code in (401, 403, 429):
                raise IngestError("The site blocked automated access. Open the page and paste the text instead.")
            if resp.status_code >= 400:
                raise IngestError(f"The page returned an error ({resp.status_code}).")
            ctype = resp.headers.get("Content-Type", "").lower()
            if "html" not in ctype and "text/plain" not in ctype:
                raise IngestError("The link does not point to a web page.")
            body = _read_limited(resp)
            encoding = resp.encoding or "utf-8"
        return parse_job_html(body.decode(encoding, errors="replace"), source=current)

    raise IngestError("The link redirected too many times.")


def _read_limited(resp: requests.Response) -> bytes:
    buf = bytearray()
    for chunk in resp.iter_content(chunk_size=16_384):
        buf.extend(chunk)
        if len(buf) > config.MAX_FETCH_BYTES:
            raise IngestError("The page is too large to import.")
    return bytes(buf)


def _html_to_text(fragment: str) -> str:
    soup = BeautifulSoup(fragment, "html.parser")
    for br in soup.find_all("br"):
        br.replace_with("\n")
    for li in soup.find_all("li"):
        li.insert_before("\n- ")
    for block in soup.find_all(["p", "div", "h1", "h2", "h3", "h4", "ul", "ol"]):
        block.append("\n")
    return _tidy(soup.get_text())


def _walk_jobposting(node: object) -> dict | None:
    if isinstance(node, list):
        for item in node:
            found = _walk_jobposting(item)
            if found:
                return found
    elif isinstance(node, dict):
        t = node.get("@type")
        if t == "JobPosting" or (isinstance(t, list) and "JobPosting" in t):
            return node
        for key in ("@graph", "mainEntity", "itemListElement"):
            if key in node:
                found = _walk_jobposting(node[key])
                if found:
                    return found
    return None


def parse_job_html(html_text: str, source: str = "") -> ImportedPosting:
    soup = BeautifulSoup(html_text, "html.parser")

    # 1) Structured data published by most job boards.
    for tag in soup.find_all("script", attrs={"type": "application/ld+json"}):
        try:
            data = json.loads(tag.string or tag.get_text() or "")
        except (ValueError, TypeError):
            continue
        job = _walk_jobposting(data)
        if not job:
            continue
        org = job.get("hiringOrganization")
        org_name = org.get("name", "") if isinstance(org, dict) else str(org or "")
        etype = job.get("employmentType", "")
        if isinstance(etype, list):
            etype = etype[0] if etype else ""
        salary = job.get("baseSalary")
        imported = ImportedPosting(
            title=_tidy(str(job.get("title", ""))),
            company_profile=_tidy(str(org_name)),
            description=_html_to_text(str(job.get("description", ""))),
            requirements=_html_to_text(str(job.get("qualifications", "") or job.get("skills", ""))),
            salary_range=_tidy(json.dumps(salary)) if salary else "",
            employment_type=_normalise_employment(str(etype)),
            industry=_tidy(str(job.get("industry", ""))),
            telecommuting=str(job.get("jobLocationType", "")).upper() == "TELECOMMUTE",
            source=source,
        )
        if imported.description:
            imported.notes.append("Structured job data found on the page.")
            return imported

    # 2) Visible text fallback.
    for t in soup(["script", "style", "noscript", "nav", "footer", "header", "form", "svg"]):
        t.decompose()
    title = ""
    og = soup.find("meta", attrs={"property": "og:title"})
    if og and og.get("content"):
        title = str(og["content"])
    elif soup.title and soup.title.string:
        title = soup.title.string
    main = soup.find("main") or soup.find("article") or soup.body or soup
    text = _html_to_text(str(main))
    if len(text) < 40:
        raise IngestError("No job text could be read from that page. It may need JavaScript. Paste the text instead.")
    return ImportedPosting(
        title=_tidy(title)[:150], description=text, source=source,
        notes=["Page text imported. Check the fields below."],
    )


def _normalise_employment(raw: str) -> str:
    key = raw.strip().lower().replace("_", "-").replace(" ", "-")
    mapping = {
        "full-time": "Full-time", "fulltime": "Full-time", "part-time": "Part-time",
        "parttime": "Part-time", "contractor": "Contract", "contract": "Contract",
        "temporary": "Temporary", "intern": "Other", "internship": "Other",
    }
    return mapping.get(key, "")
