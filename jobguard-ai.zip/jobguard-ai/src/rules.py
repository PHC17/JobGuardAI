"""Rule-based heuristic pre-filter.

Each rule inspects the extracted features and returns a RuleHit with a weight.
Hits are combined with a noisy-OR, so independent weak signals add up while the
score stays bounded in [0, 1]:

    score = 1 - prod(1 - w_i)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .features import ExtractedFeatures, JobPosting

MAX_EVIDENCE = 3


@dataclass(frozen=True)
class RuleHit:
    rule_id: str
    label: str            # short, human-readable name
    category: str         # content | contact | structure | language
    weight: float         # 0-1 contribution to the heuristic score
    detail: str           # one-sentence explanation of why it matters
    evidence: tuple[str, ...] = ()  # snippets from the posting (untrusted text!)


@dataclass(frozen=True)
class RuleResult:
    score: float
    hits: tuple[RuleHit, ...]


def _uniq(items: list[str]) -> tuple[str, ...]:
    seen: dict[str, None] = {}
    for i in items:
        seen.setdefault(i, None)
    return tuple(list(seen)[:MAX_EVIDENCE])


RuleFn = Callable[[JobPosting, ExtractedFeatures], RuleHit | None]


def _group_rule(group: str, rule_id: str, label: str, category: str, weight: float, detail: str) -> RuleFn:
    def rule(_: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
        hits = f.flag_hits.get(group)
        if not hits:
            return None
        return RuleHit(rule_id, label, category, weight, detail, _uniq(hits))
    return rule


def _pay_claims(_: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    claims = f.pay_claims + f.flag_hits.get("unrealistic_pay", [])
    if not claims:
        return None
    return RuleHit(
        "unrealistic_pay", "Unrealistic pay promises", "content", 0.25,
        "Legitimate employers rarely guarantee high earnings or promise income with no experience.",
        _uniq(claims),
    )


def _personal_email(_: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    if not f.personal_emails:
        return None
    return RuleHit(
        "personal_email", "Personal email address for contact", "contact", 0.25,
        "Real companies hire from a company domain; free-mail addresses are easy to create and discard.",
        _uniq(f.personal_emails),
    )


def _url_shortener(_: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    if not f.shortener_urls:
        return None
    return RuleHit(
        "url_shortener", "Shortened link hides the destination", "contact", 0.20,
        "Shortened links can conceal phishing pages or tracking redirects.",
        _uniq(f.shortener_urls),
    )


def _missing_profile(p: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    n = f.numeric["company_profile_len"]
    if n == 0:
        return RuleHit(
            "missing_profile", "No company profile", "structure", 0.12,
            "Postings with no information about the employer are harder to verify.",
        )
    if n < 50:
        return RuleHit(
            "thin_profile", "Very thin company profile", "structure", 0.07,
            "The company description is too short to confirm who is hiring.",
        )
    return None


def _no_logo(p: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    if p.has_company_logo:
        return None
    return RuleHit(
        "no_logo", "No company logo", "structure", 0.07,
        "Verified employers usually brand their postings.",
    )


def _short_description(p: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    words = len(f.text.split())
    if words >= 60:
        return None
    return RuleHit(
        "short_posting", "Unusually short posting", "structure", 0.12,
        "Genuine roles describe duties and requirements in some detail.",
        (f"{words} words in total",),
    )


def _no_requirements(p: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    if f.numeric["missing_requirements"] and f.numeric["missing_description"] == 0:
        return RuleHit(
            "no_requirements", "No stated requirements", "structure", 0.07,
            "Roles with no qualifications listed are common in low-effort or fraudulent postings.",
        )
    return None


def _shouting(_: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    ratio, bangs = f.numeric["uppercase_ratio"], f.numeric["exclamation_count"]
    ev: list[str] = []
    if ratio > 0.25 and f.numeric["word_count"] > 20:
        ev.append(f"{ratio:.0%} of letters are capitals")
    if bangs >= 3:
        ev.append(f"{int(bangs)} exclamation marks")
    if not ev:
        return None
    return RuleHit(
        "shouting", "Hype-style formatting", "language", 0.10,
        "Heavy capitalisation and exclamation marks are typical of mass-produced scam copy.",
        tuple(ev),
    )


def _hype_sentiment(_: JobPosting, f: ExtractedFeatures) -> RuleHit | None:
    if f.numeric["sentiment_compound"] > 0.95 and f.numeric["exclamation_count"] >= 1:
        return RuleHit(
            "hype_tone", "Overly promotional tone", "language", 0.06,
            "Extremely upbeat copy with little concrete detail can signal a bait posting.",
        )
    return None


RULES: tuple[RuleFn, ...] = (
    _group_rule(
        "advance_fee", "advance_fee", "Asks for money or payment", "content", 0.55,
        "Employers never charge applicants. Fees, deposits and gift-card payments are the clearest scam signal.",
    ),
    _group_rule(
        "identity_harvest", "identity_harvest", "Requests sensitive personal data", "content", 0.45,
        "Bank, ID or one-time-password details should never be requested before a verified offer.",
    ),
    _group_rule(
        "off_platform", "off_platform", "Moves the conversation to a chat app", "contact", 0.25,
        "Scammers push candidates to messaging apps to avoid platform monitoring.",
    ),
    _group_rule(
        "interview_bypass", "interview_bypass", "Skips a normal interview", "content", 0.25,
        "Instant hiring or chat-only interviews are not how legitimate employers operate.",
    ),
    _group_rule(
        "urgency", "urgency", "Pressure to act immediately", "language", 0.15,
        "Artificial urgency is used to stop candidates from verifying the employer.",
    ),
    _group_rule(
        "high_risk_role", "high_risk_role", "Role type often used in scams", "content", 0.10,
        "Data-entry, reshipping and payment-processing roles are frequently used as cover for fraud.",
    ),
    _pay_claims,
    _personal_email,
    _url_shortener,
    _missing_profile,
    _no_logo,
    _short_description,
    _no_requirements,
    _shouting,
    _hype_sentiment,
)


#: Display list of (label, weight) for the Risk Insights page. Keep in sync with RULES above.
SIGNAL_LIBRARY: tuple[tuple[str, float], ...] = (
    ("Asks for money or payment", 0.55),
    ("Requests sensitive personal data", 0.45),
    ("Moves the conversation to a chat app", 0.25),
    ("Skips a normal interview", 0.25),
    ("Personal email address for contact", 0.25),
    ("Unrealistic pay promises", 0.25),
    ("Shortened link hides the destination", 0.20),
    ("Pressure to act immediately", 0.15),
    ("No company profile", 0.12),
    ("Unusually short posting", 0.12),
)


def evaluate(posting: JobPosting, features: ExtractedFeatures) -> RuleResult:
    """Run every rule; return the noisy-OR heuristic score and the hits (strongest first)."""
    hits: list[RuleHit] = []
    for rule in RULES:
        hit = rule(posting, features)
        if hit is not None:
            hits.append(hit)
    hits.sort(key=lambda h: h.weight, reverse=True)

    survive = 1.0
    for h in hits:
        survive *= 1.0 - h.weight
    return RuleResult(score=round(1.0 - survive, 4), hits=tuple(hits))
