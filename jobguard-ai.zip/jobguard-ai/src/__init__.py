"""JobGuard AI: job posting risk screening engine."""
