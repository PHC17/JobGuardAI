"""Personalised recommendations.

Advice depends on (1) the risk level, (2) the audience (job seeker or recruiter)
and (3) the actual drivers found in this posting: rule hits with their evidence,
plus the strongest SHAP contributions. Evidence strings come from untrusted
posting text; the UI layer is responsible for HTML-escaping them.
"""
from __future__ import annotations

from dataclasses import dataclass

from .model import Contribution
from .rules import RuleHit

AUDIENCES = ("job_seeker", "recruiter")


@dataclass(frozen=True)
class Recommendation:
    title: str
    detail: str
    priority: int          # 1 = most urgent
    because: str = ""      # the specific driver that triggered this advice


# ---------------------------------------------------------------------------
# Level-wide guidance
# ---------------------------------------------------------------------------
HEADLINES: dict[str, dict[str, str]] = {
    "Critical": {
        "job_seeker": "Do not engage with this posting.",
        "recruiter": "Block this posting and escalate for review.",
    },
    "High": {
        "job_seeker": "Treat as likely fraudulent until the employer is verified.",
        "recruiter": "Hold this posting for manual review before it goes live.",
    },
    "Medium": {
        "job_seeker": "Proceed carefully and verify the employer first.",
        "recruiter": "Request corrections before approving this posting.",
    },
    "Low": {
        "job_seeker": "No major warning signs found. Apply normal precautions.",
        "recruiter": "No major warning signs. Safe to approve.",
    },
}

LEVEL_ACTIONS: dict[str, dict[str, list[tuple[str, str]]]] = {
    "Critical": {
        "job_seeker": [
            ("Stop and do not share personal details",
             "Do not send documents, bank details or payments. Close the conversation if you have started one."),
            ("Report the posting",
             "Flag it on the platform where you found it so others are protected."),
        ],
        "recruiter": [
            ("Unpublish and preserve the record",
             "Keep the posting, poster account and contact details for your trust-and-safety team."),
            ("Check the poster account",
             "Review other postings from the same account or contact address."),
        ],
    },
    "High": {
        "job_seeker": [
            ("Verify the employer independently",
             "Find the company's own website through a search engine (not from this posting) and look for the same role under its careers page."),
            ("Hold back sensitive information",
             "Share nothing beyond a resume until the employer is confirmed."),
        ],
        "recruiter": [
            ("Route to manual review",
             "Confirm the employer's identity and contact domain before publishing."),
        ],
    },
    "Medium": {
        "job_seeker": [
            ("Confirm who is hiring",
             "Check the company website, a business registry or a professional network profile and look for matching contacts."),
            ("Ask for a video or phone interview",
             "Legitimate employers can interview through a company channel."),
        ],
        "recruiter": [
            ("Ask the poster to fill the gaps",
             "Request company details, a company-domain contact and a clearer description."),
        ],
    },
    "Low": {
        "job_seeker": [
            ("Keep standard checks in place",
             "Never pay to apply, and share ID or bank details only after a signed offer."),
        ],
        "recruiter": [
            ("Approve",
             "Optionally ask the poster to add any missing profile details."),
        ],
    },
}

# ---------------------------------------------------------------------------
# Driver-specific advice (keyed by rule_id)
# ---------------------------------------------------------------------------
RULE_ADVICE: dict[str, dict[str, tuple[str, str]]] = {
    "advance_fee": {
        "job_seeker": ("Never pay to get a job",
                       "Genuine employers do not charge for training, equipment, registration or background checks."),
        "recruiter": ("Remove payment requests",
                      "Postings that ask applicants for money breach most platform policies."),
    },
    "identity_harvest": {
        "job_seeker": ("Withhold ID and banking details",
                       "Provide these only after a written offer from a verified employer, and only through official channels."),
        "recruiter": ("Remove requests for sensitive data",
                      "Collect identity and bank details later, through a secure onboarding process."),
    },
    "off_platform": {
        "job_seeker": ("Keep communication on official channels",
                       "Be wary of recruiters who insist on a chat app. Ask for a company email address."),
        "recruiter": ("Use company channels",
                      "Replace chat-app contact details with a company email or applicant system."),
    },
    "personal_email": {
        "job_seeker": ("Check the sender domain",
                       "A company hiring at scale uses its own domain. Compare it with the website you found yourself."),
        "recruiter": ("Use a company email",
                      "Replace free-mail contacts with an address on your company domain."),
    },
    "unrealistic_pay": {
        "job_seeker": ("Treat the pay claims with suspicion",
                       "Compare the salary with similar roles. Guaranteed income with no experience is a classic bait."),
        "recruiter": ("State realistic compensation",
                      "Replace earning promises with a clear salary range."),
    },
    "interview_bypass": {
        "job_seeker": ("Expect a real interview",
                       "Instant hiring or chat-only interviews are not normal practice."),
        "recruiter": ("Describe the hiring process",
                      "Explain the interview steps so candidates know what to expect."),
    },
    "urgency": {
        "job_seeker": ("Take your time",
                       "Pressure to act today is meant to stop you from checking details."),
        "recruiter": ("Remove urgency language",
                      "Phrases like “limited slots” make postings look like scams."),
    },
    "url_shortener": {
        "job_seeker": ("Do not open shortened links",
                       "Ask for the full address, or search for the company yourself."),
        "recruiter": ("Use full links",
                      "Link directly to your careers page."),
    },
    "missing_profile": {
        "job_seeker": ("Look for the employer elsewhere",
                       "The posting says little about the company. Search for it by name and check for reviews."),
        "recruiter": ("Add a company profile",
                      "Describe the company, its location and its website."),
    },
    "no_logo": {
        "job_seeker": ("Check the company's official presence",
                       "Look for a verified page on a professional network or the company website."),
        "recruiter": ("Add your logo",
                      "Branded postings are trusted more by applicants."),
    },
    "short_posting": {
        "job_seeker": ("Ask for the full job description",
                       "A real role can describe duties, tools and team in more detail."),
        "recruiter": ("Expand the description",
                      "Add responsibilities, requirements and the hiring process."),
    },
}

# SHAP drivers worth calling out, keyed by feature name -> (job_seeker, recruiter)
DRIVER_ADVICE: dict[str, tuple[str, str]] = {
    "has_company_logo": ("The missing company logo weighed heavily in this score.",
                         "Adding a logo would lower the risk score."),
    "missing_company_profile": ("The lack of a company profile weighed heavily in this score.",
                                "Adding a company profile would lower the risk score."),
    "has_salary_range": ("No salary information raised the score.",
                         "Adding a salary range would lower the risk score."),
    "red_flag_count": ("Scam-style phrasing raised the score.",
                       "Reword the flagged phrases to lower the risk score."),
    "has_personal_email": ("A personal email contact raised the score.",
                           "Use a company email address to lower the risk score."),
}

_LEVEL_PRIORITY = {"Critical": 1, "High": 1, "Medium": 2, "Low": 3}


def headline_for(level: str, audience: str = "job_seeker") -> str:
    return HEADLINES.get(level, HEADLINES["Medium"]).get(audience, HEADLINES[level]["job_seeker"])


def build_recommendations(
    level: str,
    hits: tuple[RuleHit, ...] | list[RuleHit],
    contributions: list[Contribution] | None = None,
    audience: str = "job_seeker",
    limit: int = 6,
) -> list[Recommendation]:
    """Combine level guidance, rule-specific advice and SHAP drivers into a short, ordered list."""
    aud = audience if audience in AUDIENCES else "job_seeker"
    out: list[Recommendation] = []

    # 1) Level guidance (always first).
    for title, detail in LEVEL_ACTIONS.get(level, LEVEL_ACTIONS["Medium"])[aud]:
        out.append(Recommendation(title, detail, priority=_LEVEL_PRIORITY.get(level, 2)))

    # 2) Advice tied to the rules this posting actually triggered, strongest first.
    used_topics: set[str] = set()
    for hit in hits:
        advice = RULE_ADVICE.get(hit.rule_id) or RULE_ADVICE.get(
            {"thin_profile": "missing_profile"}.get(hit.rule_id, "")
        )
        if not advice or hit.rule_id in used_topics:
            continue
        used_topics.add(hit.rule_id)
        title, detail = advice[aud]
        because = f"Found: {hit.label.lower()}"
        if hit.evidence:
            because += " (" + "; ".join(hit.evidence[:2]) + ")"
        out.append(Recommendation(title, detail, priority=2 if hit.weight >= 0.2 else 3, because=because))

    # 3) Model drivers that raise risk and are not already covered above.
    covered = {"has_personal_email": "personal_email", "has_company_logo": "no_logo",
               "missing_company_profile": "missing_profile"}
    added = 0
    for c in contributions or []:
        if added >= 2 or not c.raises_risk or c.feature not in DRIVER_ADVICE:
            continue
        if covered.get(c.feature) in used_topics:
            continue
        seeker, recruiter = DRIVER_ADVICE[c.feature]
        out.append(Recommendation(
            "Model insight", seeker if aud == "job_seeker" else recruiter,
            priority=3, because=c.label,
        ))
        added += 1

    # Low-risk postings should not be buried in weak-signal advice.
    out.sort(key=lambda r: r.priority)
    return out[: (3 if level == "Low" else limit)]
