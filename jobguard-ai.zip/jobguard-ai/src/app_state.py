"""Streamlit-side shared state: cached pipeline, settings and screening history.

Widget-state gotcha: Streamlit drops a widget's state when the widget is not
rendered in a run (e.g. while the user is on another page), and re-assigning
the key is not enough in current versions. save_state() mirrors every key in
PERSISTENT_KEYS into a shadow dict after each page run, and pages read them
back through pv() as the widget default.
"""
from __future__ import annotations

import time
from dataclasses import dataclass

import streamlit as st

from .model import ModelBundle, load_bundle
from .pipeline import ScreeningConfig, ScreeningPipeline
from .risk import bands_from_threshold

FORM_KEYS = (
    "f_title", "f_company_profile", "f_description", "f_requirements", "f_benefits",
    "f_salary_range", "f_employment_type", "f_required_experience", "f_required_education",
    "f_industry", "f_function", "f_telecommuting", "f_has_company_logo", "f_has_questions",
)
SETTING_KEYS = ("s_threshold", "s_ml_weight", "s_theme", "s_audience")
PERSISTENT_KEYS = FORM_KEYS + SETTING_KEYS

SETTING_DEFAULTS = {"s_threshold": 0.55, "s_ml_weight": 0.65, "s_theme": "Dark", "s_audience": "Job seeker"}
FORM_DEFAULTS: dict[str, object] = {
    **{k: "" for k in FORM_KEYS if k not in ("f_telecommuting", "f_has_company_logo", "f_has_questions")},
    "f_telecommuting": False, "f_has_company_logo": False, "f_has_questions": False,
}
HISTORY_LIMIT = 500


_DEFAULTS: dict[str, object] = {**SETTING_DEFAULTS, **FORM_DEFAULTS}
_SHADOW = "_persist"


def init_state() -> None:
    """Call at the top of every run, before the page script."""
    st.session_state.setdefault("history", [])
    st.session_state.setdefault(_SHADOW, {})


def pv(key: str):
    """Persisted value for a widget: live value, else last saved, else default.

    Pass the result as the widget's own default (value=/index=/default=).
    Streamlit forgets a widget's state once its page is not rendered, so the
    default is how the value comes back; pre-setting session state does not
    reliably refresh the frontend.
    """
    if key in st.session_state:
        return st.session_state[key]
    return st.session_state.get(_SHADOW, {}).get(key, _DEFAULTS[key])


def save_state() -> None:
    """Call after the page script ran: mirror current widget values into the shadow store."""
    shadow = dict(st.session_state.get(_SHADOW, {}))
    for key in PERSISTENT_KEYS:
        if key in st.session_state:
            shadow[key] = st.session_state[key]
    st.session_state[_SHADOW] = shadow


@st.cache_resource(show_spinner=False)
def get_bundle() -> ModelBundle:
    return load_bundle()


def get_pipeline() -> ScreeningPipeline:
    return ScreeningPipeline(get_bundle())


@dataclass(frozen=True)
class Settings:
    threshold: float
    ml_weight: float
    theme: str
    audience: str  # job_seeker | recruiter


def get_settings() -> Settings:
    return Settings(
        threshold=float(pv("s_threshold")),
        ml_weight=float(pv("s_ml_weight")),
        theme=str(pv("s_theme") or "Dark"),
        audience="recruiter" if pv("s_audience") == "Recruiter" else "job_seeker",
    )


def screening_config() -> ScreeningConfig:
    s = get_settings()
    return ScreeningConfig(bands=bands_from_threshold(s.threshold), ml_weight=s.ml_weight, audience=s.audience)


def record_history(entries: list[dict]) -> None:
    """Remember what was screened in this session (feeds Risk Insights)."""
    now = time.time()
    hist: list[dict] = st.session_state["history"]
    hist.extend({**e, "ts": now} for e in entries)
    del hist[:-HISTORY_LIMIT]
