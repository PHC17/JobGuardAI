# JobGuard AI

Real-time screening of job postings for fraud signals. Built with Streamlit, scikit-learn, XGBoost, SHAP.

## Run

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
pytest -q
```

## Model files

Place trained artifacts in `models/` (or set `JOBGUARD_MODELS_DIR`):

| File | Content |
|---|---|
| `model.joblib` | fitted classifier with `predict_proba` (XGBoost) |
| `vectorizer.joblib` | fitted `TfidfVectorizer`, see `features.make_tfidf_vectorizer()` |
| `explainer.joblib` | `shap.TreeExplainer` for the classifier |
| `meta.json` | optional `{"version": "...", "released": "..."}` |

Feature matrix = `[TF-IDF | features.NUMERIC_FEATURES]`, in that order. Build the numeric block with
`features.extract_features` + `features.numeric_matrix` at training time so train and serve match.
Without these files the app runs on the rule engine alone and says so in Settings.

Only load model files you produced yourself: `joblib.load` executes pickled code.

## Layout

```
app.py                  navigation, theme, shared state
pages/01_Screen_Job.py  single posting: form, file upload, job link
pages/02_Batch_Screen.py  CSV screening, summary, downloadable results
pages/03_Risk_Insights.py patterns in what was screened
pages/04_Settings.py    threshold with live preview, theme, audience, model version
src/features.py rules.py model.py pipeline.py recommendations.py   engine
src/ingest.py           file/URL import (SSRF-guarded)
src/ui.py app_state.py  presentation and session state
assets/agent.svg        the security agent artwork
```

## Security notes

- URL import blocks non-public addresses, credentials in URLs, non-web ports, and re-validates every redirect.
  Add network-level egress rules in hostile environments (DNS rebinding is not fully covered in-app).
- Uploads: type allowlist, size/page caps, zip-bomb check. CSV export neutralises formula injection.
- All posting text is HTML-escaped before display.
- Batch screening skips SHAP (cost) and runs one vectorised model pass.
